<?php
/**
 * Nội dung trang /en/ (tiếng Anh) và /ko/ (tiếng Hàn) – thuật ngữ bất động sản chuẩn.
 * Quy định sở hữu nhà ở của người nước ngoài: Luật Nhà ở 2023 (hiệu lực 01/8/2024), chỉ nêu điểm chính.
 */

defined( 'ABSPATH' ) || exit;

function hh_lang_strings( $code ) {
	$s = array(
		'en' => array(
			'skip'          => 'Skip to content',
			'nav'           => array( 'ownership' => 'Foreign ownership', 'approved' => 'Approved projects', 'projects' => 'On sale', 'services' => 'Services', 'process' => 'Buying process', 'about' => 'About', 'contact' => 'Contact' ),
			'hotline'       => 'Call / Zalo',
			'hours'         => '8:00 am – 9:00 pm, every day',
			'brand_tag'     => 'Da Nang real estate advisor',
			'eyebrow'       => 'Da Nang · Hoi An · Vietnam',
			'h1'            => 'Da Nang Real Estate for Foreign Buyers & Investors',
			'lead'          => 'Independent advice on off-plan condominiums, resale apartments, villas and rentals in Da Nang and Hoi An – primary prices from developers, verified legal documents and support from reservation to handover.',
			'btn_zalo'      => 'Chat on Zalo',
			'btn_call'      => 'Call',
			'btn_form'      => 'Send an enquiry',
			'stat_years'    => 'Years in the Da Nang property market',
			'stat_projects' => 'Projects tracked on this website',
			'stat_selling'  => 'Projects currently on sale',
			'own_h2'        => 'Can foreigners buy property in Vietnam?',
			'own_lead'      => 'Yes. Under the 2023 Housing Law (effective 1 August 2024), foreign individuals legally entering Vietnam can own residential property in commercial housing projects. The key rules:',
			'own_items'     => array(
				array( 'Eligible property', 'Apartments (condominiums) and landed houses in commercial housing projects, outside areas restricted for national defence and security.' ),
				array( 'Foreign ownership quota', 'Foreigners may own up to 30% of the apartments in one building; for landed houses, up to 250 houses in one ward-level area.' ),
				array( 'Ownership term', 'Up to 50 years from the date the certificate is issued, and may be extended in accordance with the law. Vietnamese buyers of the same apartment receive long-term (freehold) ownership.' ),
				array( 'Title in your own name', 'You receive the Certificate of Land Use Rights and Ownership of Houses (the "Pink Book") in your name. You can sell, gift, lease or mortgage the property.' ),
				array( 'Land plots', 'Foreigners cannot directly own land plots (land use rights) – choose apartments or houses within a licensed project instead.' ),
			),
			'own_note'      => 'General information, not legal advice. Before you pay a booking deposit, Hiep checks the remaining foreign quota and the project\'s legal documents.',
			'proj_h2'       => 'Projects on sale in Da Nang',
			'proj_lead'     => 'Prices are developer list prices for reference (VAT included, before discounts) and change with each sales phase. Ask for the latest price list and available units.',
			'selling'       => 'On sale',
			'soon'          => 'Coming soon',
			'from'          => 'From %s',
			'price_ask'     => 'Price on request',
			'handover'      => 'Handover',
			'expected'      => 'expected',
			'view_vi'       => 'Project page (Vietnamese)',
			'view_tr'       => 'Read in English',
			'all_projects'  => 'All projects (Vietnamese)',
			'types'         => array( 'can-ho-so-huu-lau-dai' => 'Condominium', 'can-ho-dich-vu' => 'Serviced apartment (50-year)', 'biet-thu-lau-dai' => 'Freehold villas', 'biet-thu' => 'Resort villas', 'shophouse' => 'Townhouses & shophouses', 'dat-nen' => 'Land plots', 'thap-tang' => 'Low-rise', 'cao-tang' => 'High-rise', 'to-hop' => 'Mixed-use township' ),
			'svc_h2'        => 'How Hiep helps you',
			'svc'           => array(
				array( 'New projects (off-plan)', 'Primary price lists, sales policies, payment schedules and early-payment discounts from developers – compared side by side.' ),
				array( 'Resale & rentals', 'Resale apartments with handover completed, plus long-term rentals for living or for your company staff.' ),
				array( 'Legal due diligence', 'Investment approval, 1/500 master plan, construction permit, bank guarantee and the Sale and Purchase Agreement (SPA) – checked before you sign.' ),
				array( 'Handover & leasing', 'Unit inspection at handover, Pink Book procedures, and finding tenants if you buy to let.' ),
			),
			'steps_h2'      => 'Buying process, step by step',
			'steps'         => array(
				array( 'Brief', 'Tell Hiep your budget, purpose (live / invest / rent out) and preferred area.' ),
				array( 'Shortlist', 'Receive 3–5 suitable units with floor plans, prices and payment schedules.' ),
				array( 'Site visit', 'Visit the show unit and site in person, or by live video call from abroad.' ),
				array( 'Booking deposit', 'Reserve the unit with a refundable or non-refundable booking deposit, depending on the developer\'s policy.' ),
				array( 'Sale and Purchase Agreement', 'Sign the SPA with the developer and pay by instalments through a bank in Vietnam.' ),
				array( 'Handover & Pink Book', 'Inspect and receive the unit; the developer applies for your ownership certificate.' ),
			),
			'about_h2'      => 'About Hoang Hiep',
			'about'         => array(
				'Hoang Hiep has spent over 15 years in the property market of Da Nang and Central Vietnam, working his way up from team leader and sales manager to trading-floor director, sales director and CEO.',
				'He knows each project, each district and how to match the right property to the right need – for your own home, a holiday home or a rental investment.',
			),
			'slogan'        => 'The right need – the right value – the right legal status',
			'faq_h2'        => 'Frequently asked questions',
			'faq'           => array(
				array( 'Can I buy a property without living in Vietnam?', 'You must have legally entered Vietnam (a valid visa or entry stamp in your passport) at the time of signing. The deposit and paperwork can then be handled remotely with Hiep\'s support.' ),
				array( 'What is the difference between net area and gross area?', 'Net area (carpet area) is measured inside the walls and is the area written on the Pink Book. Gross area is measured to the wall centre lines, so it is larger – always compare prices on the same basis.' ),
				array( 'How do I pay?', 'Payments are made in Vietnamese dong by bank transfer to the developer\'s account under the SPA payment schedule. Keep your bank records for transferring money in and out of Vietnam.' ),
				array( 'Is there a bank guarantee for off-plan purchases?', 'Off-plan projects eligible for sale must have a bank guarantee for buyers\' payments. Hiep checks this document for every project he offers.' ),
			),
			'form_h2'       => 'Send an enquiry',
			'form_lead'     => 'Hiep replies within the same day via Zalo, phone or your preferred channel.',
			'f_name'        => 'Full name *',
			'f_phone'       => 'Phone / Zalo (with country code) *',
			'f_interest'    => 'I am interested in',
			'interests'     => array( 'Buying a home to live in', 'Investing / buying to let', 'Renting', 'Other' ),
			'f_msg'         => 'Message (budget, area, email…)',
			'f_btn'         => 'Send',
			'f_note'        => 'Your details are kept confidential and used only to advise you.',
			'ok'            => 'Thank you! Hiep will contact you shortly.',
			'err'           => 'Please enter your name and a valid phone number (9–15 digits, with country code).',
			'dock_call'     => 'Call',
			'dock_zalo'     => 'Chat on Zalo',
			'dock_form'     => 'Enquire',
			'disclaimer'    => 'Prices, policies and legal information are for reference and may change. Please contact Hiep for confirmed details before making a decision.',
		),
		'ko' => array(
			'skip'          => '본문 바로가기',
			'nav'           => array( 'ownership' => '외국인 소유', 'approved' => '허용 프로젝트', 'projects' => '분양 중', 'services' => '서비스', 'process' => '구매 절차', 'about' => '소개', 'contact' => '상담 문의' ),
			'hotline'       => '전화 / Zalo',
			'hours'         => '매일 오전 8시 – 오후 9시',
			'brand_tag'     => '다낭 부동산 전문가',
			'eyebrow'       => '다낭 · 호이안 · 베트남',
			'h1'            => '외국인을 위한 다낭 부동산 – 아파트 구매·임대·투자 상담',
			'lead'          => '다낭·호이안의 분양 아파트, 기존 아파트 매매, 빌라, 임대까지. 개발사 분양가, 법적 서류 확인, 예약부터 인도까지 함께합니다.',
			'btn_zalo'      => 'Zalo 상담',
			'btn_call'      => '전화',
			'btn_form'      => '상담 신청',
			'stat_years'    => '다낭 부동산 경력(년)',
			'stat_projects' => '웹사이트 등록 프로젝트',
			'stat_selling'  => '현재 분양 중 프로젝트',
			'own_h2'        => '외국인도 베트남 부동산을 살 수 있나요?',
			'own_lead'      => '네, 가능합니다. 2023년 개정 주택법(2024년 8월 1일 시행)에 따라 베트남에 합법적으로 입국한 외국인 개인은 상업용 주택 프로젝트 내 주택을 소유할 수 있습니다. 주요 내용은 다음과 같습니다.',
			'own_items'     => array(
				array( '소유 가능 부동산', '국방·안보 제한 구역을 제외한 상업용 주택 프로젝트 내 아파트(공동주택)와 단독주택.' ),
				array( '외국인 소유 한도', '한 동(건물) 전체 세대의 최대 30%, 단독주택은 동(phường) 단위 행정구역당 최대 250채.' ),
				array( '소유 기간', '소유권 증서 발급일로부터 최대 50년이며, 법에 따라 연장할 수 있습니다. 같은 아파트라도 베트남인은 영구 소유입니다.' ),
				array( '본인 명의 소유권 증서', '본인 명의의 토지사용권 및 주택소유권 증서(일명 "핑크북")를 받습니다. 매매, 증여, 임대, 담보 설정이 가능합니다.' ),
				array( '토지(필지)', '외국인은 토지사용권(필지)을 직접 소유할 수 없습니다. 인허가를 받은 프로젝트 내 아파트나 주택을 선택하세요.' ),
			),
			'own_note'      => '일반 안내이며 법률 자문이 아닙니다. 예약금 납부 전, 히엡이 남은 외국인 한도와 프로젝트 법적 서류를 확인해 드립니다.',
			'proj_h2'       => '다낭 분양 중 프로젝트',
			'proj_lead'     => '가격은 개발사 분양가 기준 참고 가격(부가세 포함, 할인 전)이며 분양 차수에 따라 변동됩니다. 최신 가격표와 잔여 세대를 문의하세요.',
			'selling'       => '분양 중',
			'soon'          => '분양 예정',
			'from'          => '%s부터',
			'price_ask'     => '가격 문의',
			'handover'      => '입주(인도)',
			'expected'      => '예정',
			'view_vi'       => '프로젝트 페이지(베트남어)',
			'view_tr'       => '한국어로 보기',
			'all_projects'  => '전체 프로젝트(베트남어)',
			'types'         => array( 'can-ho-so-huu-lau-dai' => '아파트', 'can-ho-dich-vu' => '서비스 아파트(50년)', 'biet-thu-lau-dai' => '영구 소유 빌라', 'biet-thu' => '리조트 빌라', 'shophouse' => '타운하우스·샵하우스', 'dat-nen' => '토지(필지)', 'thap-tang' => '저층 주거', 'cao-tang' => '고층', 'to-hop' => '복합 단지' ),
			'svc_h2'        => '히엡이 도와드리는 일',
			'svc'           => array(
				array( '신규 분양', '개발사 분양가표, 분양 정책, 분할 납부 일정, 조기 납부 할인을 한눈에 비교해 드립니다.' ),
				array( '기존 매물 매매·임대', '인도 완료된 아파트 매매와 거주용·주재원용 장기 임대.' ),
				array( '법적 서류 확인', '투자 승인, 1/500 상세계획, 건축 허가, 은행 지급보증, 매매계약서(SPA)를 계약 전에 확인합니다.' ),
				array( '인도 및 임대 관리', '인도 시 하자 점검, 핑크북 발급 절차, 투자 목적이라면 임차인 구하기까지.' ),
			),
			'steps_h2'      => '구매 절차',
			'steps'         => array(
				array( '상담', '예산, 목적(거주 / 투자 / 임대), 선호 지역을 알려 주세요.' ),
				array( '추천 세대', '조건에 맞는 3~5개 세대의 평면도, 가격, 납부 일정을 받아 보세요.' ),
				array( '현장 방문', '모델하우스와 현장을 직접 방문하거나 해외에서 영상 통화로 확인할 수 있습니다.' ),
				array( '예약금 납부', '개발사 정책에 따라 환불 가능 또는 불가 예약금으로 세대를 예약합니다.' ),
				array( '매매계약 체결', '개발사와 매매계약서(SPA)를 체결하고 베트남 내 은행을 통해 분할 납부합니다.' ),
				array( '인도 및 핑크북', '세대를 점검·인수하고, 개발사가 소유권 증서 발급을 신청합니다.' ),
			),
			'about_h2'      => '호앙 히엡 소개',
			'about'         => array(
				'호앙 히엡은 15년 이상 다낭과 베트남 중부 부동산 시장에서 일해 왔습니다. 팀장, 부장에서 시작해 부동산 거래소 대표, 영업 이사, CEO를 거쳤습니다.',
				'프로젝트와 지역을 잘 알기에, 실거주·세컨드 하우스·임대 투자 등 목적에 맞는 부동산을 찾아 드립니다.',
			),
			'slogan'        => '정확한 수요 – 정확한 가치 – 정확한 법적 상태',
			'faq_h2'        => '자주 묻는 질문',
			'faq'           => array(
				array( '베트남에 거주하지 않아도 구매할 수 있나요?', '계약 시점에 베트남에 합법적으로 입국한 상태(유효한 비자 또는 여권 입국 도장)여야 합니다. 이후 예약금과 서류 절차는 히엡의 도움으로 원격 진행이 가능합니다.' ),
				array( '전용면적과 공급면적의 차이는?', '전용면적(thông thủy)은 벽 안쪽 기준 면적으로 핑크북에 기재됩니다. 공급면적(tim tường)은 벽 중심선 기준이라 더 크므로, 가격은 같은 기준으로 비교하세요.' ),
				array( '대금은 어떻게 납부하나요?', '매매계약서의 납부 일정에 따라 개발사 계좌로 베트남 동(VND)을 은행 송금합니다. 해외 송금·반출을 위해 은행 거래 기록을 보관하세요.' ),
				array( '분양 아파트에 은행 지급보증이 있나요?', '분양 가능 요건을 갖춘 미준공 프로젝트는 구매자 납입금에 대한 은행 지급보증이 있어야 합니다. 히엡은 모든 프로젝트의 지급보증 서류를 확인합니다.' ),
			),
			'form_h2'       => '상담 신청',
			'form_lead'     => '당일 Zalo, 전화 또는 원하시는 방법으로 답변드립니다.',
			'f_name'        => '성함 *',
			'f_phone'       => '전화 / Zalo (국가번호 포함) *',
			'f_interest'    => '관심 분야',
			'interests'     => array( '실거주 구매', '투자 / 임대 목적 구매', '임대(렌트)', '기타' ),
			'f_msg'         => '메시지 (예산, 지역, 이메일 등)',
			'f_btn'         => '보내기',
			'f_note'        => '개인정보는 안전하게 보호되며 상담 목적으로만 사용됩니다.',
			'ok'            => '감사합니다! 곧 연락드리겠습니다.',
			'err'           => '성함과 올바른 전화번호(국가번호 포함 9~15자리)를 입력해 주세요.',
			'dock_call'     => '전화',
			'dock_zalo'     => 'Zalo 상담',
			'dock_form'     => '상담',
			'disclaimer'    => '가격, 정책, 법률 정보는 참고용이며 변경될 수 있습니다. 결정 전 반드시 히엡에게 최신 정보를 확인하세요.',
		),
	);
	return $s[ $code ] ?? $s['en'];
}

/** Giá triệu đồng → "VND 4.12 billion" / "41.2억 동". */
function hh_lang_money( $trieu, $code ) {
	if ( 'ko' === $code ) {
		return rtrim( rtrim( number_format( $trieu / 100, 1, '.', ',' ), '0' ), '.' ) . '억 동';
	}
	return $trieu >= 1000 ? 'VND ' . rtrim( rtrim( number_format( $trieu / 1000, 2, '.', ',' ), '0' ), '.' ) . ' billion' : 'VND ' . number_format( $trieu, 0, '.', ',' ) . ' million';
}

/** Tên dự án cho khách nước ngoài: bỏ phần tiếng Việt trong ngoặc, bỏ dấu ("FourS Tower (Tháp Bốn Mùa) Đà Nẵng" → "FourS Tower Da Nang"). */
function hh_lang_name( $title ) {
	$t = trim( preg_replace( '/\s*\([^)]*\)/u', '', (string) $title ) );
	return trim( preg_replace( '/\s+/u', ' ', remove_accents( $t ) ) );
}

/** Ngày bàn giao theo ngôn ngữ: "31/5/2028" → "31 May 2028" / "2028년 5월 31일"; "Quý 1/2027" → "Q1 2027" / "2027년 1분기". */
function hh_lang_date( $raw, $code ) {
	$raw = (string) $raw;
	if ( preg_match( '/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/u', $raw, $m ) && checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ) {
		return 'ko' === $code ? sprintf( '%d년 %d월 %d일', $m[3], $m[2], $m[1] ) : sprintf( '%d %s %d', $m[1], gmdate( 'F', gmmktime( 0, 0, 0, (int) $m[2], 1 ) ), $m[3] );
	}
	if ( preg_match( '/quý\s*(IV|I{1,3}|\d)\s*[\/\-–]?\s*(?:năm\s*)?(\d{4})/iu', $raw, $m ) ) {
		$q = strtr( strtoupper( $m[1] ), array( 'IV' => '4', 'III' => '3', 'II' => '2', 'I' => '1' ) );
		return 'ko' === $code ? sprintf( '%d년 %d분기', $m[2], $q ) : sprintf( 'Q%d %d', $q, $m[2] );
	}
	if ( preg_match( '/\b(\d{1,2})\/(\d{4})\b/u', $raw, $m ) && (int) $m[1] >= 1 && (int) $m[1] <= 12 ) {
		return 'ko' === $code ? sprintf( '%d년 %d월', $m[2], $m[1] ) : gmdate( 'F', gmmktime( 0, 0, 0, (int) $m[1], 1 ) ) . ' ' . $m[2];
	}
	if ( preg_match( '/^\s*(?:năm\s*)?(\d{4})\s*(?:\(dự kiến\))?\s*$/iu', $raw, $m ) ) {
		return 'ko' === $code ? $m[1] . '년' : $m[1];
	}
	return '';
}

/**
 * Dự án nhà ở thương mại UBND / Sở Xây dựng Đà Nẵng công bố cho phép tổ chức, cá nhân nước ngoài sở hữu (theo Luật Nhà ở 2023),
 * tên gọi theo văn bản công bố, số căn tối đa theo văn bản. 'selling' = thấy tin rao bán trên Batdongsan tuần 5 – 11/10/2026.
 * 'en'/'ko' = tên thương mại đang dùng trên thị trường, kèm tên ghi trong văn bản.
 */
function hh_foreign_projects() {
	return array(
		array(
			'slug'    => 'sun-symphony-residence',
			'en'      => 'Sun Symphony Residence (approved as Olalani Riverside Towers)',
			'map'     => 'Sun Symphony Residence Đà Nẵng',
			'ko'      => '선 심포니 레지던스 (Sun Symphony Residence · 공고명 Olalani Riverside Towers)',
			'area'    => array( 'Nai Hien Dong, Son Tra', '선짜 나이히엔동' ),
			'dev'     => array( 'My Phuc JSC', '미푹 주식회사' ),
			'quota'   => array( '427 apartments + 87 landed houses', '아파트 427세대 + 단독주택 87채' ),
			'batch'   => array( 'Batch 4 · Nov 2024', '4차 · 2024년 11월' ),
			'selling' => true,
		),
		array(
			'slug'    => 'sun-cosmo-residence',
			'en'      => 'Sun Cosmo Residence – The Panoma (approved as lots B4-1 & B4-2, Han River Tourism Service Area)',
			'map'     => 'Sun Cosmo Residence Đà Nẵng',
			'ko'      => '선 코스모 레지던스 – 더 파노마 (Sun Cosmo – The Panoma · 공고명 한강변 관광서비스구역 B4-1·B4-2 부지 아파트)',
			'area'    => array( 'My An, Ngu Hanh Son', '응우한선 미안' ),
			'dev'     => array( 'Cu Lao Cham Tourism Trading Investment JSC (Sun Group)', '꾸라오짬 관광무역투자 주식회사 (Sun Group)' ),
			'quota'   => array( '203 of 679 apartments', '전체 679세대 중 203세대' ),
			'batch'   => array( 'Batch 4 · Nov 2024', '4차 · 2024년 11월' ),
			'selling' => false,
		),
		array(
			'slug'    => 'sunneva-island',
			'en'      => 'Sunneva Island (approved as Hoa Quy – Dong No Riverside Urban Area)',
			'map'     => 'Sunneva Island Đà Nẵng',
			'ko'      => '선네바 아일랜드 (Sunneva Island · 공고명 호아꾸이–동노 강변 도시구역)',
			'area'    => array( 'Dong No islet, Hoa Quy, Ngu Hanh Son', '응우한선 호아꾸이 동노섬' ),
			'dev'     => array( 'Dia Cau JSC (Sun Group)', '디아까우 주식회사 (Sun Group)' ),
			'quota'   => array( '250 of 390 villas', '빌라 390채 중 250채' ),
			'batch'   => array( 'Batch 4 · Nov 2024', '4차 · 2024년 11월' ),
			'selling' => false,
		),
		array(
			'slug'    => 'newtown-diamond-da-nang',
			'en'      => 'New Town Commercial & Premium Sports Service Urban Area (Newtown)',
			'map'     => 'Newtown Diamond Đà Nẵng',
			'ko'      => '뉴타운 상업·고급 스포츠 서비스 도시구역 (Newtown)',
			'area'    => array( 'Hoa Hai, Ngu Hanh Son', '응우한선 호아하이' ),
			'dev'     => array( 'New Town Development Co., Ltd.', 'New Town 개발 유한회사' ),
			'quota'   => array( '519 apartments + 250 villas', '아파트 519세대 + 빌라 250채' ),
			'batch'   => array( 'Batch 4 · Nov 2024', '4차 · 2024년 11월' ),
			'selling' => true,
		),
		array(
			'slug'    => 'capital-square-da-nang',
			'en'      => 'Capital Square 2 Urban Area',
			'map'     => 'Capital Square Đà Nẵng',
			'ko'      => 'Capital Square 2 도시구역',
			'area'    => array( 'An Hai Bac, Son Tra', '선짜 안하이박' ),
			'dev'     => array( 'Mega Assets Co., Ltd.', 'Mega Assets 유한회사' ),
			'quota'   => array( '502 of 1,681 apartments', '전체 1,681세대 중 502세대' ),
			'batch'   => array( 'Batch 5 · Feb 2025', '5차 · 2025년 2월' ),
			'selling' => true,
		),
		array(
			'slug'    => 'capital-square-da-nang',
			'en'      => 'Capital Square 3 Urban Area',
			'map'     => 'Capital Square Đà Nẵng',
			'ko'      => 'Capital Square 3 도시구역',
			'area'    => array( 'An Hai Bac, Son Tra', '선짜 안하이박' ),
			'dev'     => array( 'SIH Real Estate Co., Ltd.', 'SIH 부동산 유한회사' ),
			'quota'   => array( '512 of 1,710 apartments', '전체 1,710세대 중 512세대' ),
			'batch'   => array( 'Batch 5 · Feb 2025', '5차 · 2025년 2월' ),
			'selling' => true,
		),
		array(
			'slug'    => 'masteri-da-nang',
			'en'      => 'Tuyen Son High-rise Apartment, Commercial Office & Housing Complex (Masteri Rivera Danang)',
			'map'     => 'Masteri Rivera Danang',
			'ko'      => '뚜옌선 고층 아파트·상업 오피스·주택 단지 (Masteri Rivera Danang)',
			'area'    => array( 'Quy My St., Hoa Cuong (Hai Chau)', '하이쩌우 호아끄엉 꾸이미 거리' ),
			'dev'     => array( 'Tuyen Son Housing Development JSC', '뚜옌선 주택개발 주식회사' ),
			'quota'   => array( '332 of 1,112 apartments (166 per tower)', '전체 1,112세대 중 332세대 (동당 166세대)' ),
			'batch'   => array( 'Batch 6 · Feb 2026', '6차 · 2026년 2월' ),
			'selling' => false,
		),
		array(
			'slug'    => '',
			'en'      => 'The Royal Boutique Hotel & Condo Da Nang (approved as Riverside Tower)',
			'map'     => 'The Royal Boutique Hotel & Condo Đà Nẵng',
			'ko'      => '더 로열 부티크 호텔 & 콘도 다낭 (The Royal · 공고명 강변 타워)',
			'area'    => array( 'Han River, Hai Chau', '하이쩌우 다낭 한강변' ),
			'dev'     => array( 'The Royal Da Nang One Member Co., Ltd.', 'The Royal Da Nang 1인 유한회사' ),
			'quota'   => array( 'As stated in the announcement', '공고 기준' ),
			'batch'   => array( 'Batch 7 · 2026', '7차 · 2026년' ),
			'selling' => false,
		),
		array(
			'slug'    => 'danang-landmark',
			'en'      => 'Da Nang Landmark Tower (approved as Da Nang Landmark Commercial Center & Apartment Complex)',
			'map'     => 'Danang Landmark Tower Đà Nẵng',
			'ko'      => '다낭 랜드마크 타워 (Da Nang Landmark Tower · 공고명 다낭 랜드마크 상업센터·아파트 복합단지)',
			'area'    => array( 'Han River, Hai Chau', '하이쩌우 다낭 한강변' ),
			'dev'     => array( 'Cosmos Housing JSC', 'Cosmos Housing 주식회사' ),
			'quota'   => array( 'As stated in the announcement', '공고 기준' ),
			'batch'   => array( 'Batch 7 · 2026', '7차 · 2026년' ),
			'selling' => true,
		),
	);
}

/** Chữ cho mục danh sách dự án người nước ngoài được mua. */
function hh_foreign_projects_text( $code ) {
	$t = array(
		'en' => array(
			'h2'      => 'Projects approved for foreign ownership in Da Nang',
			'lead'    => 'Da Nang has published these commercial housing projects in which foreign organisations and individuals may own homes (announced in batches under the 2023 Housing Law). The quota is the maximum number of units foreigners may own in each project – not the number still available.',
			'quota'   => 'Foreign quota',
			'dev'     => 'Developer',
			'selling' => 'Listings available now',
			'check'   => 'Ask for availability',
			'view'    => 'Project details',
			'map'     => 'Show on map',
			'warn'    => 'Not on the list: Vinhomes Hai Van Bay – the Department of Construction has not approved it for foreign ownership (as of April 2026), whatever some brokers claim.',
			'note'    => 'Source: announcements by the Da Nang People\'s Committee and Department of Construction, as reported up to October 2026. Before paying a deposit, always confirm the remaining foreign quota with the developer.',
		),
		'ko' => array(
			'h2'      => '다낭 외국인 소유 허용 프로젝트',
			'lead'    => '다낭시가 2023년 개정 주택법에 따라 차수별로 공고한, 외국인(개인·법인)이 주택을 소유할 수 있는 상업용 주택 프로젝트입니다. 한도는 각 프로젝트에서 외국인이 소유할 수 있는 최대 세대수이며, 잔여 세대수가 아닙니다.',
			'quota'   => '외국인 소유 한도',
			'dev'     => '시행사',
			'selling' => '현재 매물 있음',
			'check'   => '잔여 세대 문의',
			'view'    => '프로젝트 상세',
			'map'     => '지도에서 보기',
			'warn'    => '목록에 없음: 빈홈 하이반 베이(Vinhomes Hai Van Bay) – 일부 중개인의 설명과 달리 건설국은 외국인 소유를 허용하지 않았습니다 (2026년 4월 기준).',
			'note'    => '출처: 다낭시 인민위원회·건설국 공고 (2026년 10월까지 보도 기준). 예약금 납부 전 반드시 시행사에 외국인 잔여 한도를 확인하세요.',
		),
	);
	return $t[ $code ] ?? $t['en'];
}

/** Link nhúng Google Maps cho 1 dự án: ưu tiên tọa độ đã nhập ở trang dự án trên web, không có thì tìm theo tên. */
function hh_foreign_project_map( $p, $hl = 'en' ) {
	$pp     = ! empty( $p['slug'] ) ? get_page_by_path( $p['slug'], OBJECT, 'du-an' ) : null;
	$coords = $pp ? trim( (string) get_post_meta( $pp->ID, 'hh_p_map_coords', true ) ) : '';
	$q      = preg_match( '/^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$/', $coords ) ? preg_replace( '/\s+/', '', $coords ) : ( $p['map'] ?? $p['en'] );
	return 'https://maps.google.com/maps?q=' . rawurlencode( $q ) . '&hl=' . $hl . '&z=15&output=embed';
}
