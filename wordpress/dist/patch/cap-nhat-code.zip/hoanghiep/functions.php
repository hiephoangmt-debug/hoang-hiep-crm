<?php
/**
 * Hoàng Hiệp theme setup.
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'HH_CRM_VERSION' ) ) {
	add_action(
		'admin_notices',
		fn() => print '<div class="notice notice-error"><p>Giao diện Hoàng Hiệp cần plugin <strong>Hoàng Hiệp CRM</strong>: vào <a href="' . esc_url( admin_url( 'plugin-install.php?tab=upload' ) ) . '">Plugin → Cài mới → Tải plugin lên</a>, chọn file <code>hoang-hiep-crm.zip</code> rồi bấm Kích hoạt.</p></div>'
	);
	// Ngoài website: hiện trang thông báo thay vì lỗi.
	add_filter( 'template_include', fn() => get_theme_file_path( 'no-plugin.php' ), 99 );
	return;
}

require get_theme_file_path( 'inc/customizer.php' );
require get_theme_file_path( 'inc/components.php' );
require get_theme_file_path( 'inc/project-extras.php' );
require get_theme_file_path( 'inc/lang-strings.php' );
require get_theme_file_path( 'inc/content-tables.php' );
require get_theme_file_path( 'inc/project-inline-css.php' );
require get_theme_file_path( 'inc/landing.php' );
require get_theme_file_path( 'inc/seo.php' );

add_action( 'after_setup_theme', 'hoanghiep_setup' );
function hoanghiep_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 260, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_image_size( 'hh-card', 720, 480, true );
	add_image_size( 'hh-hero', 1920, 900, true );

	register_nav_menus(
		array(
			'primary' => 'Menu chính',
			'footer'  => 'Menu chân trang',
		)
	);
}

/**
 * Giao diện / plugin lên phiên bản mới → xoá toàn bộ bộ nhớ đệm LiteSpeed (cả bản điện thoại),
 * để khách không còn thấy trang cũ sau khi cập nhật.
 */
add_action( 'init', 'hoanghiep_purge_on_update', 99 );
function hoanghiep_purge_on_update() {
	$now = wp_get_theme()->get( 'Version' ) . '|' . ( defined( 'HH_CRM_VERSION' ) ? HH_CRM_VERSION : '' );
	if ( get_option( 'hoanghiep_cache_ver' ) === $now ) {
		return;
	}
	update_option( 'hoanghiep_cache_ver', $now, true );
	do_action( 'litespeed_purge_all' );
}

add_action( 'wp_enqueue_scripts', 'hoanghiep_assets' );
function hoanghiep_assets() {
	$ver = wp_get_theme()->get( 'Version' );
	// Font Be Vietnam Pro / Playfair Display tự host trong assets/fonts (khai báo đầu main.css) – không gọi Google Fonts.
	// Thêm thời điểm sửa file vào phiên bản để trình duyệt / cache tải bản mới ngay sau khi cập nhật.
	wp_enqueue_style( 'hoanghiep', get_theme_file_uri( 'assets/css/main.css' ), array(), $ver . '.' . filemtime( get_theme_file_path( 'assets/css/main.css' ) ) );
	wp_enqueue_script( 'hoanghiep', get_theme_file_uri( 'assets/js/main.js' ), array(), $ver . '.' . filemtime( get_theme_file_path( 'assets/js/main.js' ) ), array( 'strategy' => 'defer' ) );
}

/** Tải trước font chữ chính (đoạn văn + tiêu đề) để chữ hiện ngay, không nhảy bố cục. */
add_action(
	'wp_head',
	static function () {
		foreach ( array( 'be-vietnam-pro-400-latin', 'be-vietnam-pro-400-vietnamese', 'playfair-display-700-latin' ) as $font ) {
			printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_theme_file_uri( 'assets/fonts/' . $font . '.woff2' ) ) );
		}
	},
	2
);

/** Script theo dõi gửi dữ liệu về CRM (URL và data-key công khai theo thiết kế). In đúng 1 lần mỗi trang. */
add_action(
	'wp_head',
	static function () {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		echo '<script src="https://script.google.com/macros/s/AKfycbyMWXl47PShn-ikZKwrFONJb9z89NOmVG6yIioyjGxo55IEbLh4yP7KiREPsxgSbxBl/exec?js=1" data-key="mPkoCnOIiCnl" async></script>' . "\n";
	},
	3
);

/**
 * Menu used until one is assigned in Giao diện → Menu.
 */
function hoanghiep_fallback_menu( $args = array() ) {
	$flat      = 1 === (int) ( $args['depth'] ?? 0 );
	$type_link = static function ( $slug, $fallback ) {
		$term = get_term_by( 'slug', $slug, 'loai-du-an' );
		return $term ? get_term_link( $term ) : $fallback;
	};
	$projects = get_post_type_archive_link( 'du-an' );
	$items    = array(
		array( 'Trang chủ', home_url( '/' ) ),
		array( 'Dự án', $projects, array(
			array( 'Tổ hợp dự án', $type_link( 'to-hop', $projects ) ),
			array( 'Cao tầng', $type_link( 'cao-tang', $projects ), array(
				array( 'Căn hộ sở hữu lâu dài', $type_link( 'can-ho-so-huu-lau-dai', $projects ) ),
				array( 'Căn hộ dịch vụ (50 năm)', $type_link( 'can-ho-dich-vu', $projects ) ),
			) ),
			array( 'Thấp tầng', $type_link( 'thap-tang', $projects ), array(
				array( 'Biệt thự sở hữu lâu dài', $type_link( 'biet-thu-lau-dai', $projects ) ),
				array( 'Biệt thự nghỉ dưỡng', $type_link( 'biet-thu', $projects ) ),
				array( 'Đất nền', $type_link( 'dat-nen', $projects ) ),
				array( 'Nhà phố – Shophouse', $type_link( 'shophouse', $projects ) ),
			) ),
			array( 'Căn hộ ven sông Hàn', home_url( '/can-ho-ven-song-han-da-nang/' ) ),
			array( 'Dự án căn hộ mới, sắp mở bán', home_url( '/du-an-can-ho-moi-da-nang/' ) ),
			array( 'Căn hộ khách sạn – condotel', home_url( '/can-ho-khach-san-condotel-da-nang/' ) ),
			hoanghiep_menu_cdt_item(),
		) ),
		array( 'Mua bán', hh_deal_url( 'ban' ) ),
		array( 'Cho thuê', hh_deal_url( 'thue' ) ),
		array( 'Tin tức', home_url( '/tin-tuc/' ) ),
		array( 'Về Hiệp', home_url( '/gioi-thieu/' ) ),
		array( 'Liên hệ', home_url( '/lien-he/' ) ),
	);
	$current = untrailingslashit( home_url( strtok( add_query_arg( array() ), '?' ) ) );
	$render  = static function ( $items, $class ) use ( &$render, $current, $flat ) {
		printf( '<ul class="%s">', esc_attr( $class ) );
		foreach ( $items as $item ) {
			$classes = array();
			if ( ! empty( $item[2] ) && ! $flat ) {
				$classes[] = 'menu-item-has-children';
			}
			if ( untrailingslashit( $item[1] ) === $current ) {
				$classes[] = 'current-menu-item';
			}
			printf( '<li class="%s"><a href="%s">%s</a>', esc_attr( implode( ' ', $classes ) ), esc_url( $item[1] ), esc_html( $item[0] ) );
			if ( ! empty( $item[2] ) && ! $flat ) {
				$render( $item[2], 'sub-menu' );
			}
			echo '</li>';
		}
		echo '</ul>';
	};
	$render( $items, 'menu' );
}

add_filter( 'excerpt_length', fn() => 26 );
add_filter( 'excerpt_more', fn() => '…' );

/** Mixed archives (khu vực, tìm kiếm) show projects and listings together. */
add_action( 'pre_get_posts', 'hoanghiep_tax_query' );
function hoanghiep_tax_query( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_tax( 'khu-vuc' ) ) {
		$q->set( 'posts_per_page', 12 );
	}
}

/**
 * Web chuyển từ giao diện cũ (Elementor / Elementor Pro theme builder): trang có mẫu Elementor gán sẵn
 * vẫn hiển thị bằng mẫu của Hoàng Hiệp cho trang chủ, dự án, nhà đất, tin tức, giới thiệu, liên hệ.
 */
/** Trang bảng tính căn /du-an/<dự án>/bang-tinh/. */
add_filter(
	'template_include',
	static fn( $template ) => function_exists( 'hh_is_units_page' ) && hh_is_units_page() ? get_theme_file_path( 'bang-tinh.php' ) : $template,
	97
);

/** Trang hub theo từ khoá: /can-ho-sun-group-da-nang/, /biet-thu-hoi-an/, /can-ho-chuyen-nhuong-da-nang/, /dat-nen-hoa-xuan/. */
add_filter(
	'template_include',
	static fn( $template ) => function_exists( 'hh_hub_key' ) && hh_hub_key() ? get_theme_file_path( 'hub.php' ) : $template,
	98
);

/** Trang chủ đầu tư: /chu-dau-tu/, /chu-dau-tu/<slug>/. */
add_filter(
	'template_include',
	static fn( $template ) => function_exists( 'hh_cdt_key' ) && hh_cdt_key() ? get_theme_file_path( 'chu-dau-tu.php' ) : $template,
	98
);

/** Trang tổng hợp /san-pham/shop-khoi-de/, /san-pham/penthouse/, /san-pham/duplex/. */
add_filter(
	'template_include',
	static fn( $template ) => function_exists( 'hh_special_key' ) && hh_special_key( (string) get_query_var( 'hh_sp' ) ) ? get_theme_file_path( 'san-pham.php' ) : $template,
	98
);

add_filter( 'template_include', 'hoanghiep_override_builder_template', 999 );
function hoanghiep_override_builder_template( $template ) {
	if ( false === strpos( wp_normalize_path( (string) $template ), '/plugins/elementor' ) ) {
		return $template;
	}
	$ours = '';
	if ( is_front_page() ) {
		$ours = get_front_page_template();
	} elseif ( is_home() ) {
		$ours = get_home_template();
	} elseif ( is_singular( array( 'du-an', 'bat-dong-san', 'post' ) ) && ! ( function_exists( 'hh_is_units_page' ) && hh_is_units_page() ) ) {
		$ours = get_single_template();
	} elseif ( is_page( array( 'gioi-thieu', 'lien-he', 'tin-tuc' ) ) ) {
		$ours = get_page_template();
	} elseif ( is_tax( array( 'loai-du-an', 'khu-vuc', 'loai-bds' ) ) ) {
		$ours = get_taxonomy_template();
	} elseif ( function_exists( 'hh_is_units_page' ) && hh_is_units_page() ) {
		$ours = get_theme_file_path( 'bang-tinh.php' );
	} elseif ( function_exists( 'hh_hub_key' ) && hh_hub_key() ) {
		$ours = get_theme_file_path( 'hub.php' );
	} elseif ( function_exists( 'hh_cdt_key' ) && hh_cdt_key() ) {
		$ours = get_theme_file_path( 'chu-dau-tu.php' );
	} elseif ( get_query_var( 'hh_sp' ) ) {
		$ours = get_theme_file_path( 'san-pham.php' );
	} elseif ( is_post_type_archive( array( 'du-an', 'bat-dong-san' ) ) || is_category() ) {
		$ours = is_category() ? get_category_template() : get_archive_template();
	}
	return $ours ?: $template;
}


/** Nhắc tắt các plugin chỉ chạy được với giao diện Houzez (gây lỗi nghiêm trọng khi đã đổi giao diện). */
add_action( 'admin_notices', 'hoanghiep_old_theme_plugins_notice' );
function hoanghiep_old_theme_plugins_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	$old = array_filter(
		(array) get_option( 'active_plugins', array() ),
		static fn( $p ) => 0 === strpos( $p, 'houzez-' ) || 0 === strpos( $p, 'redux-framework/' )
	);
	if ( $old ) {
		printf(
			'<div class="notice notice-error"><p><strong>Giao diện Hoàng Hiệp:</strong> hãy <a href="%s">vô hiệu hóa</a> các plugin của giao diện Houzez cũ (%s) – chúng gây lỗi nghiêm trọng khi không dùng giao diện Houzez.</p></div>',
			esc_url( admin_url( 'plugins.php?plugin_status=active' ) ),
			esc_html( implode( ', ', array_map( static fn( $p ) => dirname( $p ), $old ) ) )
		);
	}
}

/**
 * Menu chính: tự thêm các trang "Bảng giá thị trường" vào dưới mục Mua bán (khi mục đó chưa có menu con),
 * để menu đã tạo sẵn trên web cũ cũng có, không cần sửa tay.
 */
/** Khung soạn bài trong quản trị dùng cùng kiểu chữ, căn đều 2 bên như trang xem. */
add_action(
	'after_setup_theme',
	static function () {
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/css/editor-style.css' );
	}
);

add_filter( 'wp_nav_menu_objects', 'hoanghiep_market_submenu', 10, 2 );
add_filter( 'wp_nav_menu_objects', 'hoanghiep_villa_submenu', 11, 2 );

/**
 * Menu chính đã tạo trên web: tự chèn "Biệt thự sở hữu lâu dài" vào mục Thấp tầng (trước "Biệt thự nghỉ dưỡng")
 * nếu menu chưa có link này – không cần sửa menu tay.
 */
function hoanghiep_villa_submenu( $items, $args ) {
	$term = get_term_by( 'slug', 'biet-thu-lau-dai', 'loai-du-an' );
	$low  = get_term_by( 'slug', 'thap-tang', 'loai-du-an' );
	if ( 'primary' !== ( $args->theme_location ?? '' ) || ! $term || ! $low ) {
		return $items;
	}
	$url    = untrailingslashit( get_term_link( $term ) );
	$parent = null;
	foreach ( $items as $item ) {
		if ( untrailingslashit( $item->url ) === $url ) {
			return $items; // Đã có trong menu.
		}
		if ( untrailingslashit( $item->url ) === untrailingslashit( get_term_link( $low ) ) ) {
			$parent = $item;
		}
	}
	if ( ! $parent ) {
		return $items;
	}
	$child                   = clone $parent;
	$child->ID               = -2001;
	$child->db_id            = $child->ID;
	$child->menu_item_parent = (string) $parent->ID;
	$child->title            = $term->name;
	$child->url              = get_term_link( $term );
	$child->classes          = array( 'menu-item' );
	$child->current          = is_tax( 'loai-du-an', 'biet-thu-lau-dai' );
	// Chèn ngay sau mục Thấp tầng (đứng đầu nhóm con).
	$out = array();
	foreach ( $items as $item ) {
		$out[] = $item;
		if ( $item === $parent ) {
			$out[] = $child;
		}
	}
	return $out;
}
function hoanghiep_market_submenu( $items, $args ) {
	if ( 'primary' !== ( $args->theme_location ?? '' ) || ! function_exists( 'hh_deal_url' ) || ! function_exists( 'hh_market_pages' ) ) {
		return $items;
	}
	$target = untrailingslashit( hh_deal_url( 'ban' ) );
	$parent = null;
	foreach ( $items as $item ) {
		if ( untrailingslashit( $item->url ) === $target && ! $item->menu_item_parent ) {
			$parent = $item;
		}
	}
	if ( ! $parent ) {
		return $items;
	}
	foreach ( $items as $item ) {
		if ( (int) $item->menu_item_parent === (int) $parent->ID ) {
			return $items; // Đã có menu con do bạn tự tạo.
		}
	}
	$parent->classes[] = 'menu-item-has-children';
	$i                 = 0;
	foreach ( hh_market_pages() as $slug => list( $name ) ) {
		$term = get_term_by( 'slug', $slug, 'loai-bds' );
		if ( ! $term ) {
			continue;
		}
		$child                   = clone $parent;
		$child->ID               = -1000 - ( ++$i );
		$child->db_id            = $child->ID;
		$child->menu_item_parent = (string) $parent->ID;
		$child->title            = 'Bảng giá ' . mb_strtolower( $name );
		$child->url              = hh_deal_term_url( 'ban', $term );
		$child->classes          = array( 'menu-item' );
		$child->current          = false;
		$items[]                 = $child;
	}
	return $items;
}

/** Mục menu "Chủ đầu tư" (dạng mảng của menu dự phòng): vài chủ đầu tư nhiều dự án nhất + "Tất cả chủ đầu tư". */
function hoanghiep_menu_cdt_item() {
	if ( ! function_exists( 'hh_cdt_all' ) || ! hh_cdt_all() ) {
		return array( 'Chủ đầu tư', home_url( '/chu-dau-tu/' ) );
	}
	$rank = array();
	foreach ( hh_cdt_all() as $slug => $d ) {
		$rank[ $slug ] = array( count( hh_cdt_projects( $slug ) ), count( (array) ( $d['projects'] ?? array() ) ) );
	}
	arsort( $rank );
	$kids = array();
	foreach ( array_slice( array_keys( $rank ), 0, 8 ) as $slug ) {
		$kids[] = array( trim( preg_replace( '/\s*\([^)]*\)\s*$/u', '', hh_cdt_all()[ $slug ]['name'] ) ), hh_cdt_url( $slug ) );
	}
	foreach ( function_exists( 'hh_cdt_groups' ) ? hh_cdt_groups() : array() as $gk => $g ) {
		$kids[] = array( $g['menu'], hh_cdt_url( $gk ) );
	}
	$kids[] = array( 'Tất cả chủ đầu tư (' . count( hh_cdt_all() ) . ')', hh_cdt_url() );
	return array( 'Chủ đầu tư', hh_cdt_url(), $kids );
}

/** Menu chính (menu tạo trong Giao diện → Menu): thêm "Chủ đầu tư" vào cuối nhánh "Dự án" nếu menu chưa có link /chu-dau-tu/. */
add_filter(
	'wp_nav_menu_objects',
	static function ( $items, $args ) {
		if ( 'primary' !== ( $args->theme_location ?? '' ) || ! function_exists( 'hh_cdt_all' ) || ! hh_cdt_all() ) {
			return $items;
		}
		$parent = null;
		foreach ( $items as $it ) {
			if ( false !== strpos( (string) $it->url, '/chu-dau-tu/' ) ) {
				return $items; // Đã thêm tay trong menu.
			}
			if ( ! $parent && ! (int) $it->menu_item_parent && ( 'Dự án' === trim( wp_strip_all_tags( $it->title ) ) || untrailingslashit( (string) $it->url ) === untrailingslashit( (string) get_post_type_archive_link( 'du-an' ) ) ) ) {
				$parent = $it;
			}
		}
		if ( ! $parent ) {
			return $items;
		}
		// Vị trí chèn: sau mục con cuối cùng của "Dự án".
		$ids = array( (int) $parent->db_id );
		$pos = 0;
		foreach ( array_values( $items ) as $i => $it ) {
			if ( (int) $it->db_id === (int) $parent->db_id || in_array( (int) $it->menu_item_parent, $ids, true ) ) {
				$ids[] = (int) $it->db_id;
				$pos   = $i + 1;
			}
		}
		$make = static function ( $id, $parent_id, $title, $url, $has_kids = false ) {
			$current = untrailingslashit( home_url( add_query_arg( array() ) ) ) === untrailingslashit( $url );
			return (object) array(
				'ID'               => $id,
				'db_id'            => $id,
				'menu_item_parent' => $parent_id,
				'object_id'        => $id,
				'object'           => 'custom',
				'type'             => 'custom',
				'type_label'       => 'Liên kết tự tạo',
				'title'            => $title,
				'url'              => $url,
				'target'           => '',
				'attr_title'       => '',
				'description'      => '',
				'xfn'              => '',
				'status'           => 'publish',
				'classes'          => array_filter( array( 'menu-item', 'menu-item-type-custom', $has_kids ? 'menu-item-has-children' : '', $current ? 'current-menu-item' : '' ) ),
				'current'          => $current,
			);
		};
		$tree = hoanghiep_menu_cdt_item();
		$add  = array();
		$hubs = array(
			array( 'Căn hộ ven sông Hàn', '/can-ho-ven-song-han-da-nang/' ),
			array( 'Dự án căn hộ mới, sắp mở bán', '/du-an-can-ho-moi-da-nang/' ),
			array( 'Căn hộ khách sạn – condotel', '/can-ho-khach-san-condotel-da-nang/' ),
		);
		foreach ( $hubs as $i => $h ) {
			$found = false;
			foreach ( $items as $it ) {
				$found = $found || false !== strpos( (string) $it->url, $h[1] );
			}
			if ( ! $found ) {
				$add[] = $make( 989990 + $i, (int) $parent->db_id, $h[0], home_url( $h[1] ) );
			}
		}
		$add[] = $make( 990000, (int) $parent->db_id, $tree[0], $tree[1], ! empty( $tree[2] ) );
		foreach ( (array) ( $tree[2] ?? array() ) as $i => $kid ) {
			$add[] = $make( 990001 + $i, 990000, $kid[0], $kid[1] );
		}
		$items = array_values( $items );
		array_splice( $items, $pos, 0, $add );
		if ( ! in_array( 'menu-item-has-children', (array) $parent->classes, true ) ) {
			$parent->classes[] = 'menu-item-has-children';
		}
		return $items;
	},
	10,
	2
);

/** Chân trang: thêm link "Chủ đầu tư" (/chu-dau-tu/) vào menu Danh mục khi đã có hồ sơ chủ đầu tư. */
add_filter(
	'wp_nav_menu_items',
	static function ( $items, $args ) {
		if ( 'footer' !== ( $args->theme_location ?? '' ) || ! function_exists( 'hh_cdt_all' ) || ! hh_cdt_all() || false !== strpos( $items, '/chu-dau-tu/' ) ) {
			return $items;
		}
		return $items . '<li class="menu-item"><a href="' . esc_url( hh_cdt_url() ) . '">Chủ đầu tư</a></li>';
	},
	10,
	2
);
