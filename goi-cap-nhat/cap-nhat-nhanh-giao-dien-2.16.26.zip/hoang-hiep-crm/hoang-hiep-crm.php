<?php
/**
 * Plugin Name: Hoàng Hiệp CRM
 * Description: Dự án, nhà đất mua bán / cho thuê, khách hàng tiềm năng và dữ liệu dự án Đà Nẵng cho hiephoangmt.com. Dùng kèm giao diện Hoàng Hiệp.
 * Version: 2.20.256
 * Author: Hoàng Hiệp
 * Requires PHP: 7.4
 */

defined( 'ABSPATH' ) || exit;

// Bản mu-plugin (Docker) đã nạp rồi thì bỏ qua.
if ( defined( 'HH_CRM_VERSION' ) ) {
	return;
}

define( 'HH_CRM_VERSION', '2.20.256' );
define( 'HH_CRM_DIR', __DIR__ . '/hh-crm/' );
define( 'HH_CRM_URL', plugin_dir_url( __FILE__ ) . 'hh-crm/' );

require HH_CRM_DIR . 'fields.php';
require HH_CRM_DIR . 'schemas.php';
require HH_CRM_DIR . 'types.php';
require HH_CRM_DIR . 'thu-tu-du-an.php';
require HH_CRM_DIR . 'nha-o-xa-hoi.php';
require HH_CRM_DIR . 'project-content.php';
require HH_CRM_DIR . 'units-read.php';
require HH_CRM_DIR . 'units.php';
require HH_CRM_DIR . 'image-links.php';
require HH_CRM_DIR . 'rankmath.php';
require HH_CRM_DIR . 'seo-tu-khoa.php';
require HH_CRM_DIR . 'seo-don-trang-mau.php';
require HH_CRM_DIR . 'anh-webp.php';
require HH_CRM_DIR . 'indexnow.php';
require HH_CRM_DIR . 'lien-ket-noi-bo.php';
require HH_CRM_DIR . 'spana-bo-ma-can.php';
require HH_CRM_DIR . 'faq-cach-go-tim-kiem.php';
require HH_CRM_DIR . 'sua-so-can-fours.php';
require HH_CRM_DIR . 'hub-pages.php';
require HH_CRM_DIR . 'chu-dau-tu.php';
require HH_CRM_DIR . 'data-du-an-tong-hop.php';
require HH_CRM_DIR . 'data-chu-dau-tu-sua.php';
require HH_CRM_DIR . 'leads.php';
require HH_CRM_DIR . 'nguon-khach.php';
require HH_CRM_DIR . 'chat.php';
require HH_CRM_DIR . 'chat-nhung.php';
require HH_CRM_DIR . 'chat-hieu.php';
require HH_CRM_DIR . 'telegram.php';
require HH_CRM_DIR . 'mat-bang-gia.php';
require HH_CRM_DIR . 'data-du-an.php';
require HH_CRM_DIR . 'data-du-an-chi-tiet.php';
require HH_CRM_DIR . 'data-vinhomes-hai-van-bay.php';
require HH_CRM_DIR . 'data-vinhomes-hai-van-bay-2026-10.php';
require HH_CRM_DIR . 'data-hai-van-bay-phan-khu.php';
require HH_CRM_DIR . 'data-fours-tower-f2.php';
require HH_CRM_DIR . 'data-fours-f2-mat-bang.php';
require HH_CRM_DIR . 'data-fours-4d.php';
require HH_CRM_DIR . 'data-fours-f1-f5.php';
require HH_CRM_DIR . 'data-fpt-plaza-3-mat-bang.php';
require HH_CRM_DIR . 'data-vo-chi-cong-thuc-te.php';
require HH_CRM_DIR . 'data-dam-sen-anh.php';
require HH_CRM_DIR . 'data-sun-symphony-mat-bang.php';
require HH_CRM_DIR . 'data-sun-ponte-gia-thue.php';
require HH_CRM_DIR . 'data-sun-ponte-mat-bang.php';
require HH_CRM_DIR . 'data-spana-tien-do.php';
require HH_CRM_DIR . 'data-penthouse-spana-cora-s-light.php';
require HH_CRM_DIR . 'data-sun-anh-drive-11-2026.php';
require HH_CRM_DIR . 'data-da-nang-downtown-anh.php';
require HH_CRM_DIR . 'data-hoiana-beach-villas-11-2026.php';
require HH_CRM_DIR . 'anh-drive-trong-bai.php';
require HH_CRM_DIR . 'tai-truoc-trang.php';
require HH_CRM_DIR . 'data-fusion-csbh-11-2026.php';
require HH_CRM_DIR . 'chan-ban-tin-tong-hop.php';
require HH_CRM_DIR . 'data-sun-chinh-sach-11-2026.php';
require HH_CRM_DIR . 'data-spana-shophouse.php';
require HH_CRM_DIR . 'data-sun-ponte-tien-do.php';
require HH_CRM_DIR . 'data-meta-city-tam-ky.php';
require HH_CRM_DIR . 'data-camellia-tien-do.php';
require HH_CRM_DIR . 'data-tin-quy-hoach-hoa-tien-2050.php';
require HH_CRM_DIR . 'data-tin-chinh-sach-bds-11-2026.php';
require HH_CRM_DIR . 'data-fusion-anh.php';
require HH_CRM_DIR . 'data-casamia-balanca-anh.php';
require HH_CRM_DIR . 'data-sun-group-da-nang.php';
require HH_CRM_DIR . 'data-sunneva-island.php';
require HH_CRM_DIR . 'data-sun-solar-csbh04.php';
require HH_CRM_DIR . 'data-sun-solar-11-2026.php';
require HH_CRM_DIR . 'data-sun-symphony-5-11-2026.php';
require HH_CRM_DIR . 'data-fpt-plaza-4-11-2026.php';
require HH_CRM_DIR . 'data-sun-symphony-11-2026.php';
require HH_CRM_DIR . 'data-toa-do-du-an.php';
require HH_CRM_DIR . 'data-biet-thu-ven-bien.php';
require HH_CRM_DIR . 'data-vinpearl-villa.php';
require HH_CRM_DIR . 'data-shantira.php';
require HH_CRM_DIR . 'data-dat-nen-dien-ngoc.php';
require HH_CRM_DIR . 'data-nam-hoi-an-vinh-an-hoa.php';
require HH_CRM_DIR . 'data-newtown.php';
require HH_CRM_DIR . 'data-capital-square.php';
require HH_CRM_DIR . 'data-capital-square-hudson-place.php';
require HH_CRM_DIR . 'data-capital-square-c3.php';
require HH_CRM_DIR . 'data-sun-saphia.php';
require HH_CRM_DIR . 'data-sun-saphia-4d.php';
require HH_CRM_DIR . 'data-gio-hang-10-2026.php';
require HH_CRM_DIR . 'data-gio-hang-euro-village-2.php';
require HH_CRM_DIR . 'data-nam-viet-a.php';
require HH_CRM_DIR . 'data-filmore.php';
require HH_CRM_DIR . 'data-du-an-moi-a.php';
require HH_CRM_DIR . 'data-du-an-moi-b.php';
require HH_CRM_DIR . 'data-du-an-moi-c.php';
require HH_CRM_DIR . 'data-the-poet-residence.php';
require HH_CRM_DIR . 'data-landmark.php';
require HH_CRM_DIR . 'data-m-riverside.php';
require HH_CRM_DIR . 'data-san-pham-cao-tang.php';
require HH_CRM_DIR . 'data-gia-thi-truong.php';
require HH_CRM_DIR . 'data-tin-nha-dat.php';
require HH_CRM_DIR . 'data-tin-nha-dat-le.php';
require HH_CRM_DIR . 'data-tin-khach-san-11-2026.php';
require HH_CRM_DIR . 'data-tin-biet-thu-11-2026.php';
require HH_CRM_DIR . 'data-tin-nam-hoi-an-city-11-2026.php';
require HH_CRM_DIR . 'data-hoa-xuan-flycam-8-2025.php';
require HH_CRM_DIR . 'data-gop-hoa-xuan-sun-neo-city.php';
require HH_CRM_DIR . 'data-capital-square-11-2026.php';
require HH_CRM_DIR . 'data-tin-newtown-ruby-11-2026.php';
require HH_CRM_DIR . 'data-camellia-11-2026.php';
require HH_CRM_DIR . 'data-the-legend-11-2026.php';
require HH_CRM_DIR . 'data-fpt-plaza-2-mat-bang-11-2026.php';
require HH_CRM_DIR . 'data-shantira-mat-bang-11-2026.php';
require HH_CRM_DIR . 'data-fpt-plaza-3-11-2026.php';
require HH_CRM_DIR . 'data-peninsula-11-2026.php';
require HH_CRM_DIR . 'data-mia-center-point-11-2026.php';
require HH_CRM_DIR . 'data-fours-11-2026.php';
require HH_CRM_DIR . 'data-sun-riverpolis-tmb-11-2026.php';
require HH_CRM_DIR . 'data-grand-marina-da-nang-11-2026.php';
require HH_CRM_DIR . 'data-peninsula-private-11-2026.php';
require HH_CRM_DIR . 'data-gio-hang-cora-symphony5-11-2026.php';
require HH_CRM_DIR . 'data-tra-loi-nhanh-11-2026.php';
require HH_CRM_DIR . 'data-capital-square-csbh-11-2026.php';
require HH_CRM_DIR . 'data-nobu-11-2026.php';
require HH_CRM_DIR . 'metricool-theo-doi.php';
require HH_CRM_DIR . 'data-gia-dat-khach-san.php';
require HH_CRM_DIR . 'data-tin-tuc-ha-tang.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-01-02.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-03-04.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-05-06.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-07-08.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-09-10.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-11-12.php';
require HH_CRM_DIR . 'data-bai-viet-tuan-13-14.php';
require HH_CRM_DIR . 'tu-dong-dang-bai.php';
require HH_CRM_DIR . 'data-tin-nhip-song.php';
require HH_CRM_DIR . 'data-tin-cau-song-han.php';
require HH_CRM_DIR . 'data-tin-thang-10-2026.php';
require HH_CRM_DIR . 'data-tin-quy-hoach-chung-2050.php';
require HH_CRM_DIR . 'data-tin-kinh-te-dem-my-khe.php';
require HH_CRM_DIR . 'data-tin-phan-luong-cau-hoa-xuan.php';
require HH_CRM_DIR . 'data-tin-kdl-sinh-thai-ven-bien-ngu-hanh-son.php';
require HH_CRM_DIR . 'the-tin-tuc.php';
require HH_CRM_DIR . 'cap-nhat-nhanh.php';
require HH_CRM_DIR . 'ngon-ngu.php';
require HH_CRM_DIR . 'nhap-du-an-nhanh.php';
require HH_CRM_DIR . 'nhap-bai-nhanh.php';
require HH_CRM_DIR . 'data-bai-viet-casamia-dong-tien.php';
require HH_CRM_DIR . 'anh-dai-dien-bai-cu.php';
require HH_CRM_DIR . 'gop-cora-cu.php';
require HH_CRM_DIR . 'anh-dai-dien-du-an.php';
require HH_CRM_DIR . 'su-kien-sun-saphia-15-11.php';
require HH_CRM_DIR . 'data-anh-du-an-cu.php';
require HH_CRM_DIR . 'trang-thong-ke-dau-tu.php';
require HH_CRM_DIR . 'trang-ban-do-du-an.php';
require HH_CRM_DIR . 'trang-chinh-sach-bang-tinh.php';
require HH_CRM_DIR . 'setup.php';
require HH_CRM_DIR . 'houzez-import.php';

register_activation_hook( __FILE__, static function () {
	update_option( 'hh_flush_rewrite', 1 );
} );
