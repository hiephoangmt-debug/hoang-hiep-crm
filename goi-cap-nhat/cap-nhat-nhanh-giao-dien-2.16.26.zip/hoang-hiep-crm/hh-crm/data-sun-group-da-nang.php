<?php
/**
 * Dự án Sun Group tại Đà Nẵng mở bán 2025 – 2026: Sun NeO City (Hòa Xuân), Sun Riverpolis (Hòa Quý),
 * Đà Nẵng Downtown và Sun Galaxy Complex. Tổng hợp từ báo chí và trang phân phối (10/2026).
 * Số căn, bàn giao lấy theo nguồn công khai – nguồn có chỗ chưa thống nhất, cần đối chiếu chủ đầu tư.
 *
 * Slug "cora-tower" trùng dự án CORA TOWER đã có trên web: trình nhập chỉ điền ô trống, gắn vào tổ hợp.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'hh_project_dataset', 'hh_dataset_sun_group_da_nang' );
function hh_dataset_sun_group_da_nang( $projects ) {
	$sun = 'Tập đoàn Sun Group (Sun Property phát triển)';

	/* ---------------- Sun NeO City – Hòa Xuân ---------------- */
	$projects[] = array(
		'slug'    => 'sun-neo-city',
		'fix_meta' => array( 'hh_p_zones' => array( "Cora Tower | Căn hộ, shophouse khối đế | Giao Nguyễn Phước Lan – 29/3 | Đang mở bán\nSpana Tower (A1.3, A1.4) | Căn hộ, penthouse, shophouse khối đế | 2 tòa 22 tầng, khoảng 1.281 căn | Đang mở bán\nS-Light Tower | Căn hộ, penthouse | 2 tòa 22 tầng, gần 800 căn | Ra mắt 6/2026\nSunneva Island | Thấp tầng ven sông | – | Theo đợt mở bán" ) ),
		'title'   => 'Sun NeO City Hòa Xuân',
		'type'    => array( 'to-hop', 'can-ho-so-huu-lau-dai' ),
		'area'    => 'cam-le',
		'hot'     => true,
		'excerpt' => 'Khu đô thị của Sun Group tại Hòa Xuân, phía Nam Đà Nẵng – cùng Sun Riverpolis tạo hệ sinh thái hơn 1.000 ha. Gồm các tòa căn hộ Cora Tower, Spana Tower, S-Light Tower và phân khu Sunneva Island.',
		'meta'    => array(
			'hh_p_status'        => 'dang-mo-ban',
			'hh_p_developer'     => $sun,
			'hh_p_type'          => 'Căn hộ, shophouse khối đế, nhà phố, biệt thự ven sông',
			'hh_p_address'       => 'Phường Hòa Xuân (cũ), phía Nam Đà Nẵng – ven sông Cẩm Lệ, chân cầu Hòa Xuân',
			'hh_p_scale'         => 'Thuộc hệ sinh thái hơn 1.000 ha cùng Sun Riverpolis',
			'hh_p_ownership'     => 'Căn hộ sở hữu lâu dài',
			'hh_p_highlights'    => "Khu đô thị quy hoạch đồng bộ phía Nam Đà Nẵng, ven sông, nhìn về pháo hoa DIFF\nCác tòa căn hộ đang mở bán: Cora Tower, Spana Tower, S-Light Tower\nKết nối nhanh trung tâm qua cầu Hòa Xuân, Nguyễn Phước Lan, đường 29/3",
			'hh_p_zones'         => "Cora Tower | Căn hộ, shophouse khối đế | Giao Nguyễn Phước Lan – 29/3 | Đang mở bán\nSpana Tower (A1.3, A1.4) | Căn hộ, penthouse, shophouse khối đế | 2 tòa 22 tầng, 1.237 căn (S1: 661, S2: 576) | Đang mở bán\nS-Light Tower | Căn hộ, penthouse | 2 tòa 22 tầng, gần 800 căn | Ra mắt 6/2026\nSunneva Island | Thấp tầng ven sông | – | Theo đợt mở bán",
			'hh_p_location_desc' => 'Sun NeO City nằm ở phía Nam Đà Nẵng, khu vực Hòa Xuân ven sông Cẩm Lệ, nơi giao nhau của sông Hàn, sông Cẩm Lệ và sông Đô Toả. Khu đô thị kết nối trung tâm qua cầu Hòa Xuân và các trục Nguyễn Phước Lan, đường 29/3.',
			'hh_p_connections'   => "10 phút | Trung tâm thành phố, cầu Rồng\n10 phút | Sân bay quốc tế Đà Nẵng\n20 phút | Chùa Linh Ứng Sơn Trà\n30 phút | Phố cổ Hội An",
		),
		'sources' => array( 'https://sunpropertygroup.vn/cac-du-an/sun-neo-city-9553', 'https://baothanhhoa.vn/sun-group-gioi-thieu-cora-tower-tam-diem-moi-phia-nam-da-nang-265228.htm' ),
	);
	$projects[] = array(
		'slug'    => 'cora-tower',
		'title'   => 'Cora Tower Đà Nẵng',
		'type'    => 'can-ho-so-huu-lau-dai',
		'area'    => 'cam-le',
		'parent'  => 'sun-neo-city',
		'hot'     => true,
		'excerpt' => 'Tòa căn hộ của Sun Group tại giao lộ Nguyễn Phước Lan – đường 29/3, trung tâm khu đô thị Sun NeO City (Hòa Xuân, Đà Nẵng); căn Studio đến 3 phòng ngủ, bàn giao hoàn thiện cơ bản.',
		'meta'    => array(
			'hh_p_status'       => 'dang-mo-ban',
			'hh_p_developer'    => $sun,
			'hh_p_type'         => 'Căn hộ, shophouse khối đế',
			'hh_p_address'      => 'Giao lộ Nguyễn Phước Lan – đường 29/3, khu đô thị Sun NeO City, Hòa Xuân, Đà Nẵng',
			'hh_p_units'        => 'Mỗi tòa 616 căn hộ điển hình, 28 căn/tầng',
			'hh_p_ownership'    => 'Sở hữu lâu dài',
			'hh_p_handover'     => '30/07/2027 (dự kiến)',
			'hh_p_handover_std' => 'Hoàn thiện trần, tường, sàn (chưa gồm nội thất rời)',
			'hh_p_unit_types'   => "Studio | – | – | Liên hệ\nCăn 1PN+ | – | 1 | Liên hệ\nCăn 2PN | – | 2 | Liên hệ\nCăn 3PN | – | 3 | Liên hệ",
			'hh_p_design_desc'  => 'Mỗi tầng 28 căn: 6 Studio, 16 căn 1PN+, 5 căn 2PN và 1 căn 3PN. Mỗi tòa có 132 Studio, 352 căn 1PN+, 110 căn 2PN, 22 căn 3PN.',
			'hh_p_location_desc' => 'Cora Tower tọa lạc tại giao lộ Nguyễn Phước Lan và đường 29/3 – vị trí trung tâm của khu đô thị Sun NeO City (Nam Hòa Xuân), phía Nam Đà Nẵng.',
		),
		'sources' => array( 'https://baothanhhoa.vn/sun-group-gioi-thieu-cora-tower-tam-diem-moi-phia-nam-da-nang-265228.htm', 'https://congly.com.vn/cora-tower-tam-diem-dau-tu-moi-cua-sun-group-tai-nam-da-nang/', 'https://scdgroup.vn/sun-cora-tower' ),
	);
	$projects[] = array(
		'slug'    => 'spana-tower',
		'fix_meta' => array(
			'hh_p_highlights'   => array( "Pháp lý đầy đủ: Sở Xây dựng xác nhận nhà ở hình thành trong tương lai đủ điều kiện bán (VB 7111/SXD-QLN, 05/5/2026)\nNgân hàng VietinBank cam kết phát hành bảo lãnh cho người mua (07/5/2026); dự án không thế chấp khi ký HĐMB\nĐất ở đô thị (đất xây dựng chung cư), 2 sổ riêng cho lô A1-3 và A1-4\nSở Xây dựng thẩm định báo cáo nghiên cứu khả thi (VB 6978/SXD-CPXD, 29/4/2026)\nQuy hoạch chi tiết 1/500 điều chỉnh (QĐ 365/QĐ-UBND phường Hòa Xuân, 11/3/2026); chủ trương đầu tư điều chỉnh (QĐ 206/QĐ-UBND TP Đà Nẵng, 13/01/2026)\nHợp đồng mua bán theo mẫu đã đăng ký với Sở Công Thương (TB 1737/TB-SCT, 09/4/2026)\nNgay chân cầu Hòa Xuân, ven sông Cẩm Lệ – 2 tòa 22 tầng, 1.237 căn, tiện ích trọn tầng 2" ),
			'hh_p_developer'    => array( 'Tập đoàn Sun Group (Sun Property phát triển)' ),
			'hh_p_address'      => array( 'Mặt tiền Nguyễn Phước Lan, chân cầu Hòa Xuân, khu đô thị Sun NeO City, Đà Nẵng' ),
			'hh_p_blocks'       => array( '2 tòa (A1.3, A1.4)', '2 tòa S1, S2 (lô A1.3, A1.4) hai bên đường dẫn cầu Hòa Xuân' ),
			'hh_p_floors'       => array( '22 tầng nổi, 2 tầng hầm' ),
			'hh_p_units'        => array( 'Khoảng 1.281 căn hộ' ),
			'hh_p_legal'        => array( 'Sổ đất ở đô thị (đất xây dựng chung cư); Sở Xây dựng xác nhận đủ điều kiện bán nhà ở hình thành trong tương lai (VB 7111/SXD-QLN ngày 05/5/2026); bảo lãnh VietinBank; không thế chấp', 'Dự án KĐT sinh thái ven sông Hòa Xuân có giấy chứng nhận đầu tư từ 28/5/2010; tên thương mại Spana Tower theo thông báo CĐT 322A/2025/TB-SHD (15/8/2025); sổ đất ở đô thị (đất xây dựng chung cư); Sở Xây dựng xác nhận đủ điều kiện bán nhà ở hình thành trong tương lai (VB 7111/SXD-QLN ngày 05/5/2026); bảo lãnh VietinBank; không thế chấp' ),
			'hh_p_image_links'  => array( "plugin:img/spana-tower/spana-tower-toan-canh-ven-song-cau-hoa-xuan.jpg | Phối cảnh Spana Tower bên sông Cẩm Lệ, chân cầu Hòa Xuân, Đà Nẵng | đại diện\nplugin:img/spana-tower/spana-tower-truc-duong-chinh-2-toa.jpg | Hai tòa Spana Tower A1.3, A1.4 hai bên trục đường dẫn cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-phoi-canh-tren-cao-ven-song.jpg | Spana Tower nhìn từ trên cao, hướng sông và cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-2-toa-a13-a14-nhin-tu-tren-cao.jpg | Hai tòa Spana Tower và khu nhà phố Sun NeO City ven sông | thư viện\nplugin:img/spana-tower/spana-tower-hoang-hon-khoi-de-thuong-mai.jpg | Khối đế thương mại Spana Tower lúc hoàng hôn | tiện ích", "plugin:img/spana-tower/spana-tower-toan-canh-ven-song-cau-hoa-xuan.jpg | Phối cảnh Spana Tower bên sông Cẩm Lệ, chân cầu Hòa Xuân, Đà Nẵng | đại diện\nplugin:img/spana-tower/spana-tower-truc-duong-chinh-2-toa.jpg | Hai tòa Spana Tower A1.3, A1.4 hai bên trục đường dẫn cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-phoi-canh-tren-cao-ven-song.jpg | Spana Tower nhìn từ trên cao, hướng sông và cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-2-toa-a13-a14-nhin-tu-tren-cao.jpg | Hai tòa Spana Tower và khu nhà phố Sun NeO City ven sông | thư viện\nplugin:img/spana-tower/spana-tower-hoang-hon-khoi-de-thuong-mai.jpg | Khối đế thương mại Spana Tower lúc hoàng hôn | tiện ích\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-1-shophouse.jpg | Mặt bằng S1 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S1 – Tầng 1 (shophouse)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-2-tien-ich.jpg | Mặt bằng S1 – Tầng 2 (tiện ích) Spana Tower | mặt bằng | S1 – Tầng 2 (tiện ích)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3.jpg | Mặt bằng S1 – Tầng 3 Spana Tower | mặt bằng | S1 – Tầng 3\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3a-21.jpg | Mặt bằng S1 – Tầng 3A – 21 Spana Tower | mặt bằng | S1 – Tầng 3A – 21\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-1-shophouse.jpg | Mặt bằng S2 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S2 – Tầng 1 (shophouse)", "plugin:img/spana-tower/spana-tower-toan-canh-ven-song-cau-hoa-xuan.jpg | Phối cảnh Spana Tower bên sông Cẩm Lệ, chân cầu Hòa Xuân, Đà Nẵng | đại diện\nplugin:img/spana-tower/spana-tower-truc-duong-chinh-2-toa.jpg | Hai tòa Spana Tower A1.3, A1.4 hai bên trục đường dẫn cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-phoi-canh-tren-cao-ven-song.jpg | Spana Tower nhìn từ trên cao, hướng sông và cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-2-toa-a13-a14-nhin-tu-tren-cao.jpg | Hai tòa Spana Tower và khu nhà phố Sun NeO City ven sông | thư viện\nplugin:img/spana-tower/spana-tower-hoang-hon-khoi-de-thuong-mai.jpg | Khối đế thương mại Spana Tower lúc hoàng hôn | tiện ích\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-1-shophouse.jpg | Mặt bằng S1 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S1 – Tầng 1 (shophouse)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-2-tien-ich.jpg | Mặt bằng S1 – Tầng 2 (tiện ích) Spana Tower | mặt bằng | S1 – Tầng 2 (tiện ích)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3.jpg | Mặt bằng S1 – Tầng 3 Spana Tower | mặt bằng | S1 – Tầng 3\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3a-21.jpg | Mặt bằng S1 – Tầng 3A – 21 Spana Tower | mặt bằng | S1 – Tầng 3A – 21\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-1-shophouse.jpg | Mặt bằng S2 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S2 – Tầng 1 (shophouse)\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-2-tien-ich.jpg | Mặt bằng S2 – Tầng 2 (tiện ích) Spana Tower | mặt bằng | S2 – Tầng 2 (tiện ích)\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-3-7.jpg | Mặt bằng S2 – Tầng 3 – 7 Spana Tower | mặt bằng | S2 – Tầng 3 – 7\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-8-21.jpg | Mặt bằng S2 – Tầng 8 – 21 Spana Tower | mặt bằng | S2 – Tầng 8 – 21\nplugin:img/spana-tower/spana-tower-mat-bang-tong-the-s1-s2.jpg | Mặt bằng tổng thể Spana Tower: Tòa S1, S2 hai bên đường dẫn cầu Hòa Xuân, ven sông Cẩm Lệ | tổng thể" ),
			'hh_p_unit_types'   => array( "Studio | – | – | Liên hệ\nCăn 1PN+ | – | 1 | Liên hệ\nCăn 2PN | – | 2 | Liên hệ\nCăn 3PN | – | 3 | Liên hệ", "Studio | 31,6 m² (tim tường 35,5 m²) | – | Liên hệ\nCăn 1PN+ | 54,2 m² (tim tường 58,7 m²) | 1 | Liên hệ\nCăn 2PN | 62,2 – 75,1 m² (tim tường 67,2 – 80,4 m²) | 2 | Liên hệ\nCăn 3PN | 95,5 – 96,9 m² (tim tường 102,1 – 104,4 m²) | 3 | Liên hệ\nShophouse tầng 1 | 46,5 – 140,4 m² | – | Liên hệ" ),
			'hh_p_amenities_in' => "Hồ bơi\nGym & spa\nKids club\nShophouse khối đế tầng 1 – 2",
			'hh_p_shop_desc'    => 'Tầng 1 – 2 bố trí shophouse khối đế và tiện ích nội khu.',
		),
		'title'   => 'Spana Tower Hòa Xuân',
		'fix_excerpt' => 'Hai tòa căn hộ A1.3 và A1.4 của Sun Group ngay chân cầu Hòa Xuân, mặt tiền Nguyễn Phước Lan: 22 tầng, khoảng 1.281 căn từ Studio đến Penthouse, khối đế shophouse và tiện ích.',
		'type'    => 'can-ho-so-huu-lau-dai',
		'area'    => 'cam-le',
		'parent'  => 'sun-neo-city',
		'excerpt' => 'Spana Tower – 2 tòa căn hộ S1 (lô A1-3) và S2 (lô A1-4) của Sun Group ngay chân cầu Hòa Xuân, ven sông Cẩm Lệ: 22 tầng + tum, 1.237 căn từ Studio đến 3PN, shophouse khối đế. Sở Xây dựng xác nhận đủ điều kiện bán (5/5/2026), bảo lãnh VietinBank.',
		'meta'    => array(
			'hh_p_status'      => 'dang-mo-ban',
			'hh_p_developer'   => 'Công ty CP Tập đoàn Mặt Trời (Sun Group), Sun Property phát triển',
			'hh_p_scale'       => 'Lô A1-3 (S1) 4.163 m², lô A1-4 (S2) 3.572 m²',
			'hh_p_density'     => '72% (S1), 71% (S2)',
			'hh_p_legal'       => 'Đủ điều kiện bán (Sở Xây dựng 05/5/2026), bảo lãnh VietinBank, không thế chấp',
			'hh_p_highlights'  => "Ngay chân cầu Hòa Xuân, ven sông Cẩm Lệ – vài phút vào trung tâm, sân bay\n2 tòa 22 tầng, 1.237 căn: từ Studio 31,6 m² đến 3PN 95,5 m², shophouse khối đế\nTrọn tầng 2 tiện ích: bể bơi, gym & spa, co-working, cafe, khu trẻ em\nSở hữu lâu dài, đủ điều kiện bán, VietinBank bảo lãnh – không thế chấp\nBàn giao dự kiến 30/06/2027, thuộc khu đô thị Sun NeO City của Sun Group",
			'hh_p_legal_docs'  => "Sở Xây dựng xác nhận nhà ở hình thành trong tương lai đủ điều kiện bán (VB 7111/SXD-QLN, 05/5/2026)\nNgân hàng VietinBank cam kết phát hành bảo lãnh cho người mua (07/5/2026); dự án không thế chấp khi ký HĐMB\nĐất ở đô thị (đất xây dựng chung cư), 2 sổ riêng cho lô A1-3 và A1-4\nSở Xây dựng thẩm định báo cáo nghiên cứu khả thi (VB 6978/SXD-CPXD, 29/4/2026)\nQuy hoạch chi tiết 1/500 điều chỉnh (QĐ 365/QĐ-UBND phường Hòa Xuân, 11/3/2026)\nChủ trương đầu tư điều chỉnh (QĐ 206/QĐ-UBND TP Đà Nẵng, 13/01/2026)\nHợp đồng mua bán theo mẫu đã đăng ký với Sở Công Thương (TB 1737/TB-SCT, 09/4/2026)",
			'hh_p_type'        => 'Căn hộ, penthouse, shophouse khối đế',
			'hh_p_address'     => 'Lô A1-3, A1-4 Khu đô thị sinh thái ven sông Hòa Xuân (Sun NeO City), chân cầu Hòa Xuân – giáp Giáng Hương 2, Nguyễn Văn Thông, Nguyễn Mậu Tài, Ngô Huy Diễn, phường Hòa Xuân, Đà Nẵng',
			'hh_p_blocks'      => '2 tòa: S1 (lô A1-3) và S2 (lô A1-4), hai bên đường dẫn cầu Hòa Xuân',
			'hh_p_floors'      => '22 tầng + tum, 2 tầng hầm, cao 85,95 m',
			'hh_p_units'       => '1.237 căn hộ (S1: 661 căn, S2: 576 căn)',
			'hh_p_ownership'   => 'Sở hữu lâu dài',
			'hh_p_handover'    => '30/06/2027 (dự kiến)',
			'hh_p_unit_types'  => "Studio – tòa S2 | 31,6 m² (tim tường 35,51 m²) | – | Liên hệ\n1PN+ – tòa S2 | 54,2 m² (tim tường 58,71 m²) | 1 | Liên hệ\n2PN – tòa S1 | 62,2 m² (tim tường 67,2 m²) | 2 | Liên hệ\n2PN – tòa S1 | 65,6 m² (tim tường 71,4 m²) | 2 | Liên hệ\n2PN – tòa S1 | 75,1 m² (tim tường 80,4 m²) | 2 | Liên hệ\n2PN – tòa S2 | 78,7 m² (tim tường 84,75 m²) | 2 | Liên hệ\n3PN – tòa S2 | 76,8 m² (tim tường 83,5 m²) | 3 | Liên hệ\n3PN – tòa S1 | 95,5 m² (tim tường 102,1 m²) | 3 | Liên hệ\nShophouse tầng 1 | 46,5 – 140,4 m² | – | Liên hệ",
			'hh_p_shop_desc'   => 'Tầng 1 mỗi tòa (S1, S2) bố trí khoảng 24 – 25 căn shophouse mặt đường, diện tích 46,5 – 140,4 m²; tầng 2 là tiện ích nội khu (bể bơi, gym & spa, co-working, cafe, khu trẻ em).',
			'hh_p_penthouse_desc' => 'Có căn Penthouse trên các tầng cao – liên hệ để nhận danh sách căn.',
			'hh_p_amenities_in' => "Bể bơi tầng 2\nGym & spa\nKhu vui chơi trẻ em\nPhòng sinh hoạt cộng đồng\nCo-working\nCafe\nShophouse khối đế tầng 1",
			'hh_p_connections' => "Chân cầu | Cầu Hòa Xuân\n10 phút | Trung tâm thành phố, cầu Rồng\n10 phút | Sân bay quốc tế Đà Nẵng\n30 phút | Bán đảo Sơn Trà, phố cổ Hội An",
			// Phối cảnh chủ đầu tư (anh Hiệp gửi 09/10/2026), ảnh đi kèm plugin trong img/spana-tower/.
			'hh_p_image_links' => "plugin:img/spana-tower/spana-tower-toan-canh-ven-song-cau-hoa-xuan.jpg | Phối cảnh Spana Tower bên sông Cẩm Lệ, chân cầu Hòa Xuân, Đà Nẵng | đại diện\nplugin:img/spana-tower/spana-tower-truc-duong-chinh-2-toa.jpg | Hai tòa Spana Tower A1.3, A1.4 hai bên trục đường dẫn cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-phoi-canh-tren-cao-ven-song.jpg | Spana Tower nhìn từ trên cao, hướng sông và cầu Hòa Xuân | thư viện\nplugin:img/spana-tower/spana-tower-2-toa-a13-a14-nhin-tu-tren-cao.jpg | Hai tòa Spana Tower và khu nhà phố Sun NeO City ven sông | thư viện\nplugin:img/spana-tower/spana-tower-hoang-hon-khoi-de-thuong-mai.jpg | Khối đế thương mại Spana Tower lúc hoàng hôn | tiện ích\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-1-shophouse.jpg | Mặt bằng S1 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S1 – Tầng 1 (shophouse)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-2-tien-ich.jpg | Mặt bằng S1 – Tầng 2 (tiện ích) Spana Tower | mặt bằng | S1 – Tầng 2 (tiện ích)\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3.jpg | Mặt bằng S1 – Tầng 3 Spana Tower | mặt bằng | S1 – Tầng 3\nplugin:img/spana-tower/spana-tower-mat-bang-s1-tang-3a-21.jpg | Mặt bằng S1 – Tầng 3A – 21 Spana Tower | mặt bằng | S1 – Tầng 3A – 21\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-1-shophouse.jpg | Mặt bằng S2 – Tầng 1 (shophouse) Spana Tower | mặt bằng | S2 – Tầng 1 (shophouse)\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-2-tien-ich.jpg | Mặt bằng S2 – Tầng 2 (tiện ích) Spana Tower | mặt bằng | S2 – Tầng 2 (tiện ích)\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-3-7.jpg | Mặt bằng S2 – Tầng 3 – 7 Spana Tower | mặt bằng | S2 – Tầng 3 – 7\nplugin:img/spana-tower/spana-tower-mat-bang-s2-tang-8-21.jpg | Mặt bằng S2 – Tầng 8 – 21 Spana Tower | mặt bằng | S2 – Tầng 8 – 21\nplugin:img/spana-tower/spana-tower-mat-bang-tong-the-s1-s2.jpg | Mặt bằng tổng thể Spana Tower: Tòa S1, S2 hai bên đường dẫn cầu Hòa Xuân, ven sông Cẩm Lệ | tổng thể\nplugin:img/spana-tower/spana-tower-layout-3pn-s20801.jpg | Layout căn 3PN – tòa S2, 76,8 m² Spana Tower (bản vẽ chủ đầu tư) | layout | 3PN – tòa S2, 76,8 m²\nplugin:img/spana-tower/spana-tower-layout-3pn-s10801.jpg | Layout căn 3PN – tòa S1, 95,5 m² Spana Tower (bản vẽ chủ đầu tư) | layout | 3PN – tòa S1, 95,5 m²\nplugin:img/spana-tower/spana-tower-layout-2pn-s10816.jpg | Layout căn 2PN – tòa S1, 62,2 m² Spana Tower (bản vẽ chủ đầu tư) | layout | 2PN – tòa S1, 62,2 m²\nplugin:img/spana-tower/spana-tower-layout-2pn-s10811.jpg | Layout căn 2PN – tòa S1, 65,6 m² Spana Tower (bản vẽ chủ đầu tư) | layout | 2PN – tòa S1, 65,6 m²\nplugin:img/spana-tower/spana-tower-layout-2pn-s10832.jpg | Layout căn 2PN – tòa S1, 75,1 m² Spana Tower (bản vẽ chủ đầu tư) | layout | 2PN – tòa S1, 75,1 m²",
		),
		'sources' => array( 'https://spanatower.bdssungroupdanang.vn', 'https://minhminhgroup.vn/sun-group-mo-ban-can-ho-hoa-xuan-spana-tower/', 'https://sunurbancityhanam.vn/sun-spana-tower/' ),
	);
	$projects[] = array(
		'slug'    => 's-light-tower',
		'title'   => 'S-Light Tower Đà Nẵng',
		'type'    => 'can-ho-so-huu-lau-dai',
		'area'    => 'cam-le',
		'parent'  => 'sun-neo-city',
		'hot'     => true,
		'excerpt' => 'Cặp tháp căn hộ 22 tầng của Sun Property tại Sun NeO City (Hòa Xuân), nơi giao ba dòng sông Hàn – Cẩm Lệ – Đô Toả: gần 800 căn từ 33,3 đến 95,1 m², view sông và pháo hoa DIFF.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => $sun,
			'hh_p_type'       => 'Căn hộ, penthouse',
			'hh_p_address'    => 'Đường 29/3 giao Nguyễn Đình Thi, khu đô thị Sun NeO City, Hòa Xuân, Đà Nẵng',
			'hh_p_blocks'     => '2 tháp',
			'hh_p_floors'     => '22 tầng nổi, 3 tầng hầm',
			'hh_p_units'      => 'Gần 800 căn hộ',
			'hh_p_unit_area'  => '33,3 – 95,1 m²',
			'hh_p_ownership'  => 'Sở hữu lâu dài',
			'hh_p_unit_types' => "Studio | Từ 33,3 m² | – | Liên hệ\nCăn 1PN+ | – | 1 | Liên hệ\nCăn 2PN | – | 2 | Liên hệ\nCăn 3PN góc | Đến 95,1 m² | 3 | Liên hệ",
			'hh_p_penthouse_desc' => 'Có dòng Penthouse – liên hệ để nhận danh sách căn.',
			'hh_p_highlights' => "Ngã ba sông Hàn – Cẩm Lệ – Đô Toả, tầm nhìn 270° ra sông và pháo hoa DIFF\n100% căn hộ đón nắng và gió tự nhiên\nSở hữu lâu dài",
			'hh_p_progress'   => '6/2026 | Sun Property ra mắt S-Light Tower',
		),
		'sources' => array( 'https://cafef.vn/sun-property-ra-mat-s-light-tower-tam-diem-vuong-khi-trung-tam-nam-da-nang-188260622082242751.chn', 'https://anninhthudo.vn/sun-property-ra-mat-s-light-tower-tam-diem-vuong-khi-trung-tam-nam-da-nang-post657042.antd' ),
	);

	/* ---------------- Sun Riverpolis – Hòa Quý (Nam Hòa Xuân) ---------------- */
	$projects[] = array(
		'slug'    => 'sun-riverpolis',
		'title'   => 'Sun Riverpolis Nam Hòa Xuân',
		'type'    => array( 'to-hop', 'can-ho-so-huu-lau-dai', 'dat-nen', 'biet-thu' ),
		'area'    => 'ngu-hanh-son',
		'excerpt' => 'Khu đô thị sinh thái của Sun Group tại Hòa Quý (Nam Hòa Xuân, Đà Nẵng) – cùng Sun NeO City tạo hệ sinh thái hơn 1.000 ha phía Nam thành phố. Phân khu căn hộ đầu tiên: FourS Tower.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => $sun,
			'hh_p_type'       => 'Căn hộ, đất nền, nhà phố, biệt thự ven sông',
			'hh_p_address'    => 'Phường Hòa Quý (cũ), Ngũ Hành Sơn, Đà Nẵng – khu đô thị Nam Hòa Xuân',
			'hh_p_scale'      => 'Thuộc hệ sinh thái hơn 1.000 ha cùng Sun NeO City',
			'hh_p_zones'      => "FourS Tower (Mai – Trúc – Cúc – Tùng) | Căn hộ | 4 tòa 20 tầng, 2.394 căn | Ra mắt 3/2026\nĐất nền Đầm Sen | Đất nền, biệt thự view sông | Khoảng 900 lô | Mở bán từ 8/2025",
			'hh_p_location_desc' => 'Sun Riverpolis nằm tại Hòa Quý, phía Nam Đà Nẵng, bao quanh bởi sông nước, gần biển và trục Nguyễn Phước Lan – Minh Mạng.',
		),
		'sources' => array( 'https://tuoitre.vn/bon-thap-can-ho-thuoc-du-an-sun-group-nam-da-nang-ra-mat-20260319112111814.htm' ),
	);
	$projects[] = array(
		'slug'    => 'fours-tower',
		'fix_meta' => array( 'hh_p_blocks' => '4 tòa (Mai, Trúc, Cúc, Tùng)' ),
		'title'   => 'FourS Tower (Tháp Bốn Mùa) Đà Nẵng',
		'type'    => 'can-ho-so-huu-lau-dai',
		'area'    => 'ngu-hanh-son',
		'parent'  => 'sun-riverpolis',
		'hot'     => true,
		'excerpt' => 'Phân khu căn hộ đầu tiên của Sun Riverpolis (Hòa Quý, Nam Đà Nẵng): 4 tòa Mai – Trúc – Cúc – Tùng cao 20 tầng, 2.394 căn từ Studio đến 3 phòng ngủ, ngay ngã tư Nguyễn Phước Lan – Minh Mạng.',
		'meta'    => array(
			'hh_p_status'      => 'dang-mo-ban',
			'hh_p_developer'   => $sun,
			'hh_p_type'        => 'Căn hộ Studio – 3 phòng ngủ',
			'hh_p_address'     => 'Ngã tư Nguyễn Phước Lan – Minh Mạng, phường Hòa Quý (cũ), Ngũ Hành Sơn, Đà Nẵng',
			'hh_p_blocks'      => '4 tòa: F1 Tùng, F2 Mai, F3 Trúc, F5 Cúc (không dùng số 4)',
			'hh_p_zones'       => "F1 – Tháp Tùng (Mùa Đông) | Căn hộ Studio – 3PN | 20 tầng | Đang mở bán (đợt đầu từ 3/2026)\nF5 – Tháp Cúc (Mùa Thu) | Căn hộ Studio – 3PN | 20 tầng | Đang mở bán (đợt đầu từ 3/2026)\nF2 – Tháp Mai (Mùa Xuân) | Căn hộ Studio – 3PN | 20 tầng | Ra mắt 26/9/2026\nF3 – Tháp Trúc (Mùa Hạ) | Căn hộ | 20 tầng | Chưa công bố mở bán",
			'hh_p_floors'      => '20 tầng nổi, 2 tầng hầm',
			'hh_p_units'       => '2.394 căn hộ',
			'hh_p_ownership'   => 'Sở hữu lâu dài',
			'hh_p_unit_types'  => "Studio | – | – | Liên hệ\nCăn 1PN | – | 1 | Liên hệ\nCăn 2PN | – | 2 | Liên hệ\nCăn 3PN | – | 3 | Liên hệ",
			'hh_p_amenities_in' => "Hồ bơi bốn mùa\nGym, yoga, spa\nKhu vui chơi trẻ em\nKhông gian sinh hoạt cộng đồng\nPhòng khám Mặt Trời\n(Tiện ích bố trí tại tầng 2)",
			'hh_p_progress'    => '19/3/2026 | Sun Property ra mắt FourS Tower',
		),
		'sources' => array( 'https://tuoitre.vn/bon-thap-can-ho-thuoc-du-an-sun-group-nam-da-nang-ra-mat-20260319112111814.htm', 'https://tuoitre.vn/fours-tower-an-cu-dau-tu-tai-trung-tam-nam-da-nang-20260410181212744.htm' ),
	);

	/* ---------------- Đà Nẵng Downtown & Sun Galaxy Complex ---------------- */
	$projects[] = array(
		'slug'    => 'da-nang-downtown',
		'title'   => 'Đà Nẵng Downtown (Sun Group)',
		'type'    => array( 'to-hop', 'can-ho-so-huu-lau-dai' ),
		'area'    => 'hai-chau',
		'hot'     => true,
		'excerpt' => 'Siêu tổ hợp giải trí – thương mại – đô thị 76,92 ha ven sông Hàn của Sun Group trên khu đất Asia Park cũ, tổng vốn khoảng 79.790 tỷ đồng, có tòa tháp 69 tầng cao 408 m – cao nhất miền Trung. Phân khu đầu tiên Sun Galaxy Complex đang thi công cọc móng và nhận giữ chỗ.',
		'fix_excerpt' => 'Siêu tổ hợp giải trí – thương mại – đô thị 76,92 ha ven sông Hàn của Sun Group trên khu đất Asia Park cũ, tổng vốn khoảng 79.790 tỷ đồng, có tòa tháp 69 tầng cao 408 m – cao nhất miền Trung.',
		'fix_meta' => array(
			'hh_p_highlights' => array( "Tòa tháp biểu tượng 69 tầng, cao 408 m – cao nhất miền Trung\nCông viên văn hóa giải trí, nhà hát, phố thương mại ven sông Hàn\nTháp tích hợp khách sạn 5 sao, văn phòng hạng A, căn hộ cao cấp, trung tâm thương mại" ),
			'hh_p_zones' => array( "Tháp biểu tượng 69 tầng | Khách sạn 5 sao, văn phòng, căn hộ cao cấp, TTTM | 408 m | Đang thi công\nSun Galaxy Complex | Căn hộ dịch vụ, khách sạn, khán đài pháo hoa, TTTM | Hơn 210.000 m² | Khởi công 25/7/2026" ),
			'hh_p_progress' => array( "19/8/2025 | Khởi công Đà Nẵng Downtown\n25/7/2026 | Khởi công Sun Galaxy Complex" ),
		),
		'content' => <<<'HTML'
<p><strong>Đà Nẵng Downtown</strong> (Da Nang Downtown) là siêu tổ hợp văn hóa – giải trí – thương mại – đô thị 76,92 ha của Sun Group trên khu đất Công viên Châu Á (Asia Park) cũ, ven bờ Tây sông Hàn giữa cầu Trần Thị Lý và cầu Tiên Sơn. Tổng vốn khoảng 79.790 tỷ đồng, khởi công ngày 19/8/2025.</p>
<figure><img src="https://cdn.jsdelivr.net/gh/hiephoangmt-debug/hoang-hiep-crm@claude/great-tesla-ki0len/web/images/da-nang-downtown-phoi-canh-1920.webp" alt="Phối cảnh phố thương mại ven sông Đà Nẵng Downtown với tòa tháp 69 tầng" loading="lazy" width="1600"><figcaption>Phố thương mại ven sông và tòa tháp 69 tầng. Ảnh minh họa.</figcaption></figure>
<h2>Điểm nhấn của dự án</h2>
<ul>
<li><strong>Tòa tháp 69 tầng, cao 408 m</strong>: cao thứ 2 Việt Nam sau Landmark 81, cao nhất miền Trung; gồm khách sạn 5 sao, văn phòng hạng A, căn hộ cao cấp, TTTM và đài quan sát.</li>
<li><strong>Cụm văn hóa</strong>: nhà hát khoảng 4.000 chỗ, bảo tàng, trung tâm triển lãm.</li>
<li><strong>Phố thương mại ven sông</strong> và không gian lễ hội phục vụ kinh tế đêm.</li>
<li><strong>Sun Galaxy Complex</strong>: phân khu đầu tiên với vòng Moon Gate, khán đài pháo hoa khoảng 30.000 chỗ, căn hộ do Accor vận hành.</li>
</ul>
<h2>Tiến độ mới nhất (17/10/2026)</h2>
<figure><img src="https://cdn.jsdelivr.net/gh/hiephoangmt-debug/hoang-hiep-crm@claude/great-tesla-ki0len/web/images/tien-do-da-nang-downtown-17-10-2026-flycam-1600.webp" alt="Công trường Đà Nẵng Downtown ngày 17/10/2026 bên sông Hàn" loading="lazy" width="1600"><figcaption>Toàn cảnh công trường Đà Nẵng Downtown ngày 17/10/2026.</figcaption></figure>
<p>Nhiều khối công trình đang lên kết cấu, hạ tầng ven hồ và đường nội khu đang thi công. Sun Galaxy Complex đang thi công cọc móng và nhận giữ chỗ. Ngày 7/7/2026 Sun Group và Accor ký hợp tác đưa Sofitel, Swissôtel, MGallery về khu phức hợp pháo hoa DIFF.</p>
<h2>Giá bán và chính sách</h2>
<p>Chủ đầu tư chưa công bố bảng giá chính thức. Mức thị trường đang lưu hành khoảng 60–100 triệu/m² tùy phân khu, chỉ để tham khảo. Các đơn vị phân phối giới thiệu hỗ trợ vay tới 70–80%, ân hạn gốc và hỗ trợ lãi 0% tối đa 30 tháng.</p>
<h2>Xem chi tiết từng phân khu</h2>
<ul>
<li><a href="https://www.sun-danangdowntown.com/">Trang thông tin Đà Nẵng Downtown</a>: vị trí, quy hoạch, pháp lý, công cụ tính khoản vay.</li>
<li><a href="https://www.sun-galaxy-complex.com.vn/">Sun Galaxy Complex</a>: Moon Gate, khán đài 30.000 chỗ, loại căn, giá tham khảo.</li>
<li><a href="https://www.sun-danangdowntown.com/thap-69-tang">Tháp 69 tầng</a>: ý tưởng kiến trúc, công năng, so sánh các tòa nhà cao nhất Việt Nam.</li>
</ul>
<p><em>Thông tin tổng hợp từ báo chí và tài liệu giới thiệu dự án, cập nhật 23/10/2026; giá và chính sách có thể thay đổi theo chủ đầu tư.</em></p>
HTML
		,
		'meta'    => array(
			'hh_p_status'     => 'sap-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Tổ hợp: căn hộ cao cấp, khách sạn 5 sao, văn phòng, trung tâm thương mại, công viên văn hóa giải trí',
			'hh_p_address'    => 'Số 01 Phan Đăng Lưu (khu Asia Park cũ), phường Hòa Cường (cũ), Hải Châu, Đà Nẵng – ven sông Hàn',
			'hh_p_scale'      => '76,92 ha – tổng vốn khoảng 79.790 tỷ đồng',
			'hh_p_start'      => '19/8/2025',
			'hh_p_highlights' => "Tòa tháp biểu tượng 69 tầng, cao 408 m – cao nhất miền Trung, cao thứ 2 Việt Nam\nPhân khu đầu tiên Sun Galaxy Complex: Moon Gate, khán đài pháo hoa khoảng 30.000 chỗ, Accor vận hành (Sofitel, Swissôtel, MGallery)\nNhà hát khoảng 4.000 chỗ, bảo tàng, phố thương mại ven sông Hàn\nTháp tích hợp khách sạn 5 sao, văn phòng hạng A, căn hộ cao cấp, trung tâm thương mại",
			'hh_p_zones'      => "Tháp biểu tượng 69 tầng | Khách sạn 5 sao, văn phòng, căn hộ cao cấp, TTTM | 408 m | Đang thi công\nSun Galaxy Complex | Căn hộ dịch vụ Accor, khách sạn, khán đài pháo hoa, TTTM | Hơn 210.000 m² | Thi công cọc móng (17/10/2026), nhận giữ chỗ",
			'hh_p_progress'   => "19/8/2025 | Khởi công Đà Nẵng Downtown\n7/7/2026 | Sun Group và Accor ký hợp tác: Sofitel, Swissôtel, MGallery tại khu phức hợp pháo hoa DIFF\n25/7/2026 | Khởi công Sun Galaxy Complex\n17/10/2026 | Sun Galaxy Complex thi công cọc móng; nhiều khối công trình Downtown đang lên kết cấu",
			'hh_p_location_desc' => 'Đà Nẵng Downtown nằm ngay trung tâm thành phố, ven sông Hàn trong đoạn giữa cầu Trần Thị Lý và cầu Tiên Sơn, tại giao lộ Phan Đăng Lưu – Đỗ Pháp Thuận (khu Asia Park cũ).',
		),
		'sources' => array( 'https://dantri.com.vn/bat-dong-san/sun-group-khoi-cong-sieu-to-hop-giai-tri-thuong-mai-gan-80000-ty-dong-tai-da-nang-20250819202225532.htm', 'https://cafef.vn/sun-group-khoi-cong-sieu-du-an-80000-ty-dong-tai-da-nang-quyet-xay-toa-thap-cao-thu-2-viet-nam-188250819063225554.chn', 'https://baodautu.vn/batdongsan/da-nang-khoi-cong-sieu-du-an-da-nang-downtown-tong-von-gan-80000-ty-dong-d363815.html' ),
	);
	$projects[] = array(
		'slug'    => 'sun-galaxy-complex',
		'title'   => 'Sun Galaxy Complex Đà Nẵng',
		'type'    => 'can-ho-dich-vu',
		'area'    => 'ngu-hanh-son',
		'parent'  => 'da-nang-downtown',
		'hot'     => true,
		'excerpt' => 'Tổ hợp lễ hội – giải trí – căn hộ dịch vụ hơn 210.000 m² của Sun Group trên đường Chương Dương, bờ Đông sông Hàn: tháp 47 tầng với vòng Moon Gate, khán đài pháo hoa khoảng 30.000 chỗ, căn hộ do Accor (Sofitel, Swissôtel) vận hành, bàn giao full nội thất 5 sao. Khởi công 25/7/2026, đang thi công cọc móng.',
		'fix_excerpt' => 'Tổ hợp lễ hội – giải trí – căn hộ dịch vụ hơn 210.000 m² của Sun Group trên đường Chương Dương, bờ Đông sông Hàn: khán đài pháo hoa DIFF, khách sạn quốc tế, TTTM và căn hộ do Accor quản lý vận hành. Khởi công 25/7/2026.',
		'fix_meta' => array(
			'hh_p_manager' => array( 'Accor (thương hiệu Sofitel, Swissôtel) – theo đơn vị phân phối' ),
			'hh_p_units' => array( 'Khán đài gần 20.000 chỗ, TTTM 7 tầng, 114 nhà phố, khoảng 1.400 phòng lưu trú (theo báo chí); đơn vị phân phối nêu khoảng 3.800 căn hộ' ),
			'hh_p_highlights' => array( "Cổng Mặt Trăng (Moon Gate) đường kính 69 m nhìn thẳng không gian pháo hoa DIFF\nKhán đài lễ hội gần 20.000 chỗ, TTTM ven sông 7 tầng\nCăn hộ dịch vụ do Accor quản lý (theo đơn vị phân phối)" ),
			'hh_p_amenities_in' => array( "Khán đài pháo hoa DIFF\nTrung tâm thương mại ven sông 7 tầng\nHồ bơi vô cực, sky bar\nNhà hàng, gym, spa\nConcierge 24/7" ),
			'hh_p_progress' => array( '25/7/2026 | Khởi công Sun Galaxy Complex' ),
		),
		'content' => <<<'HTML'
<p><strong>Sun Galaxy Complex</strong> là phân khu đầu tiên của đại đô thị Đà Nẵng Downtown: tổ hợp lễ hội – sự kiện – lưu trú hơn 210.000 m² trên đường Chương Dương, bờ Đông sông Hàn, gần cầu Trần Thị Lý. Tổng vốn gần 10.750 tỷ đồng, khởi công ngày 25/7/2026.</p>
<figure><img src="https://cdn.jsdelivr.net/gh/hiephoangmt-debug/hoang-hiep-crm@claude/great-tesla-ki0len/web/images/sun-galaxy-complex-moon-gate-thap-hoang-hon-1600.webp" alt="Sun Galaxy Complex với vòng Moon Gate và tòa tháp 69 tầng nhìn từ sông Hàn" loading="lazy" width="1600"><figcaption>Sun Galaxy Complex (trái) và tòa tháp 69 tầng (phải) nhìn từ sông Hàn. Ảnh minh họa.</figcaption></figure>
<h2>Thông số chính</h2>
<ul>
<li>Tháp 47 tầng, cao khoảng 183 m, 4 tầng hầm.</li>
<li>Khoảng 1.400 phòng lưu trú, 114 nhà phố, TTTM ven sông 7 tầng (theo báo chí); đơn vị phân phối nêu khoảng 3.800 căn hộ.</li>
<li>Căn hộ bàn giao full nội thất tiêu chuẩn 5 sao; Studio khoảng 32,6 m², 1PN 49,1 m², 2PN 72,3 m² (theo đơn vị phân phối).</li>
<li>Vận hành: Accor với các thương hiệu Sofitel, Swissôtel, MGallery (thỏa thuận ngày 7/7/2026).</li>
</ul>
<h2>Moon Gate và hồ bơi vô cực</h2>
<figure><img src="https://cdn.jsdelivr.net/gh/hiephoangmt-debug/hoang-hiep-crm@claude/great-tesla-ki0len/web/images/sun-galaxy-complex-ho-boi-vo-cuc-moon-gate-1600.webp" alt="Hồ bơi vô cực trong vòng Moon Gate của Sun Galaxy Complex nhìn ra sông Hàn" loading="lazy" width="1600"><figcaption>Hồ bơi vô cực trong lòng vòng Moon Gate. Ảnh minh họa.</figcaption></figure>
<p>Vòng Moon Gate đường kính khoảng 69 m khoét xuyên khối tháp, nhìn thẳng ra không gian pháo hoa DIFF; bên trong là hồ bơi vô cực và sân thư giãn trên cao. Ý tưởng thiết kế "Non – Đất – Nước": các lớp Biển, Sông, Sân vườn, Ngũ Hành, Mây trời xếp từ khối đế lên đỉnh tháp.</p>
<h2>Khán đài pháo hoa khoảng 30.000 chỗ</h2>
<figure><img src="https://cdn.jsdelivr.net/gh/hiephoangmt-debug/hoang-hiep-crm@claude/great-tesla-ki0len/web/images/sun-galaxy-complex-khan-dai-30000-cho-1600.webp" alt="Phương án khán đài 30.000 chỗ của Sun Galaxy Complex hướng nhìn pháo hoa DIFF" loading="lazy" width="1600"><figcaption>Phương án khán đài bậc thang hướng nhìn trực diện pháo hoa DIFF. Ảnh minh họa theo tài liệu giới thiệu.</figcaption></figure>
<p>Khán đài bậc thang cao dần từ tầng 1 đến tầng 4, sân khấu DIFF nổi trên mặt nước, công viên ven sông và đường 6 làn đi ngầm bên dưới khán đài. Quy hoạch được duyệt ghi gần 20.000 chỗ; tài liệu giới thiệu mới nhất ghi khoảng 30.000 chỗ.</p>
<h2>Tiến độ và giá</h2>
<p>Ngày 17/10/2026 công trường đang thi công cọc móng với hàng chục máy khoan cọc nhồi. Dự án đang nhận giữ chỗ (khoảng 50 triệu/căn), chưa công bố bảng giá chính thức; các mức giá lưu hành từ 60 đến khoảng 148 triệu/m² chỉ để tham khảo.</p>
<p>Xem đầy đủ thông số, mặt bằng, công cụ tính vay và đăng ký nhận bảng giá tại <a href="https://www.sun-galaxy-complex.com.vn/">sun-galaxy-complex.com.vn</a>.</p>
<p><em>Thông tin tổng hợp từ báo chí và tài liệu giới thiệu dự án, cập nhật 23/10/2026; giá và chính sách có thể thay đổi theo chủ đầu tư.</em></p>
HTML
		,
		'meta'    => array(
			'hh_p_status'     => 'sap-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_manager'    => "Accor – thương hiệu Sofitel, Swissôtel, MGallery (thỏa thuận Sun Group – Accor ngày 7/7/2026)",
			'hh_p_type'       => 'Căn hộ dịch vụ, khách sạn quốc tế, nhà phố, trung tâm thương mại, khán đài pháo hoa',
			'hh_p_address'    => 'Đường Chương Dương, khu Mỹ An, bờ Đông sông Hàn, Ngũ Hành Sơn, Đà Nẵng – gần cầu Trần Thị Lý',
			'hh_p_scale'      => 'Hơn 210.000 m² – tổng vốn khoảng 10.750 tỷ đồng',
			'hh_p_units'      => "Khán đài khoảng 30.000 chỗ (tài liệu giới thiệu; quy hoạch duyệt gần 20.000 chỗ), TTTM 7 tầng, 114 nhà phố, khoảng 1.400 phòng lưu trú (theo báo chí); đơn vị phân phối nêu khoảng 3.800 căn hộ",
			'hh_p_unit_area'  => 'Studio 32,6 m² · 1PN 49,1 m² · 2PN 72,3 m²',
			'hh_p_start'      => '25/7/2026',
			'hh_p_handover'   => 'Khoảng 36 tháng kể từ ngày nhận bàn giao mặt bằng (dự kiến)',
			'hh_p_highlights' => "Cổng Mặt Trăng (Moon Gate) đường kính 69 m nhìn thẳng không gian pháo hoa DIFF, bên trong là hồ bơi vô cực\nKhán đài lễ hội khoảng 30.000 chỗ, sân khấu DIFF nổi trên mặt nước, đường 6 làn đi ngầm dưới khán đài\nTháp 47 tầng, 4 tầng hầm, bàn giao full nội thất tiêu chuẩn 5 sao\nAccor vận hành: Sofitel, Swissôtel, MGallery",
			'hh_p_unit_types' => "Studio | 32,6 m² | – | Liên hệ\nCăn 1PN | 49,1 m² | 1 | Liên hệ\nCăn 2PN | 72,3 m² | 2 | Liên hệ\nCăn 3 – 4PN | – | 3 | Liên hệ",
			'hh_p_amenities_in' => "Khán đài pháo hoa DIFF khoảng 30.000 chỗ\nHồ bơi vô cực trong vòng Moon Gate, hồ bơi tràn bờ trên cao\nTrung tâm thương mại ven sông, nhà hàng, sky lounge\nGym, spa, ballroom\nConcierge 24/7 theo tiêu chuẩn Accor",
			'hh_p_progress'   => "7/7/2026 | Accor ký vận hành Sofitel, Swissôtel, MGallery tại khu phức hợp pháo hoa DIFF\n25/7/2026 | Khởi công Sun Galaxy Complex\n17/10/2026 | Công trường thi công cọc móng, hàng chục máy khoan cọc nhồi ven sông Hàn",
		),
		'sources' => array( 'https://vneconomy.vn/buoc-dot-pha-trong-phat-trien-cong-nghiep-van-hoa-da-nang.htm', 'https://cafeland.vn/du-an/sun-galaxy-complex-to-hop-can-ho-tai-da-nang-5758.html' ),
	);

	/* ---------------- Đất nền Hòa Xuân, Cồn Dầu, Võ Chí Công ---------------- */
	$projects[] = array(
		'slug'    => 'kdt-sinh-thai-hoa-xuan',
		'title'   => 'Khu đô thị sinh thái Hòa Xuân',
		'type'    => array( 'to-hop', 'dat-nen', 'biet-thu' ),
		'area'    => 'cam-le',
		'excerpt' => 'Khu đô thị sinh thái ven sông Cẩm Lệ – Hòa Xuân (Cẩm Lệ, Đà Nẵng) của Sun Group, quy mô khoảng 450 ha: đất nền, nhà phố, biệt thự ven sông với các phân khu Euro Village 2, Cồn Dầu.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Đất nền, nhà phố liền kề, biệt thự ven sông',
			'hh_p_address'    => 'Phường Hòa Xuân (cũ), Cẩm Lệ, Đà Nẵng – ven sông Cẩm Lệ',
			'hh_p_scale'      => 'Khoảng 450 ha',
			'hh_p_ownership'  => 'Đất ở lâu dài, sổ đỏ từng lô',
			'hh_p_zones'      => "Euro Village 2 (giai đoạn 1B) | Nhà phố liền kề, biệt thự | 23,7 ha – 245 nhà phố, 175 biệt thự | Đã có sổ, giao dịch thứ cấp\nĐất nền Cồn Dầu | Đất nền phân lô | Khoảng 10 ha – 600 lô | Đang mở bán",
			'hh_p_location_desc' => 'Khu đô thị sinh thái Hòa Xuân nằm phía Nam trung tâm Đà Nẵng, giáp sông Cẩm Lệ, kết nối trung tâm qua cầu Hòa Xuân, cầu Nguyễn Tri Phương và trục đường 29/3, Võ Chí Công.',
		),
		'sources' => array( 'https://batdongsandanang.com.vn/chi-tiet-du-an/lang-chau-au-euro-village-2/', 'https://sungroupvn.com.vn/dat-nen-con-dau-hoa-xuan/' ),
	);
	$projects[] = array(
		'slug'    => 'dat-nen-con-dau-hoa-xuan',
		'title'   => 'Đất nền Cồn Dầu Hòa Xuân',
		'type'    => 'dat-nen',
		'area'    => 'cam-le',
		'parent'  => 'kdt-sinh-thai-hoa-xuan',
		'hot'     => true,
		'excerpt' => 'Phân khu đất nền Cồn Dầu thuộc Khu đô thị sinh thái Hòa Xuân (Cẩm Lệ, Đà Nẵng) của Sun Group: khoảng 600 lô diện tích từ 100 m², sổ đỏ từng lô, giá tham khảo từ khoảng 42 – 55 triệu/m².',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Đất nền phân lô xây tự do',
			'hh_p_address'    => 'Khu Cồn Dầu, phường Hòa Xuân (cũ), Cẩm Lệ, Đà Nẵng',
			'hh_p_scale'      => 'Khoảng 100.000 m²',
			'hh_p_units'      => 'Khoảng 600 lô',
			'hh_p_unit_area'  => 'Từ 100 m²/lô',
			'hh_p_price_m2'   => 'Khoảng 42 – 55 triệu/m² (tham khảo, tùy vị trí)',
			'hh_p_ownership'  => 'Đất ở lâu dài, sổ đỏ từng lô',
			'hh_p_dat-nen_desc'  => 'Đất nền phân lô trong khu dân cư quy hoạch đồng bộ, hạ tầng hoàn thiện. Giá tham khảo theo tin rao trên thị trường; giá thực tế theo từng lô, hướng và mặt đường.',
			'hh_p_dat-nen_table' => "Lô tiêu chuẩn | 100 m² | Đường nội khu | Từ khoảng 4,2 – 5,5 tỷ\nLô đường Cồn Dầu 16 (ví dụ tin rao) | 100 m² | Cồn Dầu 16 | Khoảng 6,5 tỷ",
		),
		'sources' => array( 'https://sungroupvn.com.vn/dat-nen-con-dau-hoa-xuan/', 'https://minhminhgroup.vn/sun-group-mo-ban-dat-nen-con-dau-hoa-xuan-da-nang/', 'https://kenhnhadatdanang.com/ban-dat-con-dau-16-da-nang/' ),
	);
	$projects[] = array(
		'slug'    => 'euro-village-2',
		'title'   => 'Euro Village 2 Hòa Xuân',
		'type'    => array( 'biet-thu', 'shophouse' ),
		'area'    => 'cam-le',
		'parent'  => 'kdt-sinh-thai-hoa-xuan',
		'excerpt' => 'Làng Châu Âu 2 – khu biệt thự, nhà phố ven sông thuộc giai đoạn 1B Khu đô thị sinh thái Hòa Xuân (Cẩm Lệ, Đà Nẵng) của Sun Group: 23,7 ha, 245 nhà phố liền kề và 175 biệt thự; giao dịch chuyển nhượng.',
		'meta'    => array(
			'hh_p_status'     => 'da-ban-giao',
			'hh_p_sold_out'   => '1',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Biệt thự, nhà phố liền kề',
			'hh_p_address'    => 'Phường Hòa Xuân (cũ), Cẩm Lệ, Đà Nẵng – giai đoạn 1B Khu đô thị sinh thái Hòa Xuân',
			'hh_p_scale'      => '23,7 ha',
			'hh_p_units'      => '245 nền nhà phố liền kề, 175 nền biệt thự',
			'hh_p_unit_area'  => 'Biệt thự khoảng 250 – 416 m²',
			'hh_p_ownership'  => 'Đất ở lâu dài, sổ đỏ',
			'hh_p_resale_price' => 'Đất biệt thự khoảng 38 – 45 triệu/m² (tham khảo)',
			'hh_p_villa_table'  => "Khu B2.8 – đường 7,5 m | – | Đất biệt thự | Khoảng 38 – 43 triệu/m²\nKhu B2.11 | – | Đất biệt thự | Khoảng 40 – 45 triệu/m²\nKhu B2.15 – lô 300 m² hướng Đông Nam (ví dụ) | 300 m² | Đất biệt thự | Khoảng 12 tỷ",
		),
		'sources' => array( 'https://batdongsandanang.com.vn/chi-tiet-du-an/lang-chau-au-euro-village-2/', 'https://www.dathoaxuandanang.com/vn/tin-tuc/ban-dat-euro-village-2-hoa-xuan-da-nang-n16.html' ),
	);
	$projects[] = array(
		'slug'    => 'dat-nen-vo-chi-cong',
		'title'   => 'Đất nền Võ Chí Công Đà Nẵng (Sun Group)',
		'type'    => 'dat-nen',
		'area'    => 'ngu-hanh-son',
		'hot'     => true,
		'excerpt' => '709 lô đất nền mặt tiền và gần đại lộ Võ Chí Công (Ngũ Hành Sơn, Đà Nẵng) của Sun Group, diện tích phổ biến 100 – 125 m², sổ hồng từng lô, mở bán từ 3/2026; kết nối AEON Mall, làng Đại học, FPT City và biển.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Đất nền phân lô xây tự do, biệt thự ven sông Đô Toả',
			'hh_p_address'    => 'Đại lộ Võ Chí Công, phường Ngũ Hành Sơn, Đà Nẵng – gần cầu Khuê Đông, sông Đô Toả',
			'hh_p_units'      => '709 lô',
			'hh_p_unit_area'  => '100 – 125 m² (phổ biến)',
			'hh_p_price_m2'   => 'Khoảng 45 – 90 triệu/m² tùy vị trí (tham khảo)',
			'hh_p_ownership'  => 'Sổ hồng từng lô',
			'hh_p_highlights' => "Mặt tiền đại lộ Võ Chí Công – trục nối Hòa Quý, khu công nghệ cao, làng Đại học và ven biển\nĐất nền phân lô xây tự do, sổ hồng từng lô\nGần AEON Mall, FPT City, biển Sơn Thủy",
			'hh_p_dat-nen_desc'  => 'Giá tham khảo theo vị trí trên trục Võ Chí Công (theo thị trường 2026); giá thực tế theo bảng giá chủ đầu tư từng đợt.',
			'hh_p_dat-nen_table' => "Gần cầu Khuê Đông | 100 – 125 m² | Võ Chí Công & nội khu | Khoảng 45 – 65 triệu/m²\nGần FPT City | 100 – 125 m² | Võ Chí Công & nội khu | Khoảng 51 – 60 triệu/m²\nGần biển | 100 – 125 m² | Võ Chí Công & nội khu | Khoảng 60 – 90 triệu/m²",
			'hh_p_progress'   => '3/2026 | Mở bán 709 lô đất nền',
		),
		'sources' => array( 'https://scdgroup.vn/tin-tuc/dat-nen-vo-chi-cong-da-nang-2026-gia-ban-phap-ly-tiem-nang-tang-gia', 'https://sungroupland.com.vn/dat-nen-sun-group-vo-chi-cong/', 'https://batdongsandanang.com.vn/chi-tiet-du-an/dat-nen-vo-chi-cong/' ),
	);

	$projects[] = array(
		'slug'    => 'dat-nen-dam-sen-sun-riverpolis',
		'title'   => 'Đất nền Đầm Sen – Sun Riverpolis Nam Hòa Xuân',
		'type'    => array( 'dat-nen', 'biet-thu' ),
		'area'    => 'ngu-hanh-son',
		'parent'  => 'sun-riverpolis',
		'hot'     => true,
		'excerpt' => 'Phân khu đất nền Đầm Sen thuộc Sun Riverpolis – Khu đô thị sinh thái Nam Hòa Xuân (Hòa Quý, Đà Nẵng) của Sun Group: khoảng 900 lô 100 – 150 m² và biệt thự view sông, sổ đỏ lâu dài, giá tham khảo từ khoảng 4,8 tỷ/lô.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => 'Tập đoàn Sun Group',
			'hh_p_type'       => 'Đất nền phân lô, đất biệt thự view sông',
			'hh_p_address'    => 'Khu Đầm Sen, phường Hòa Quý (cũ), Ngũ Hành Sơn, Đà Nẵng – khu đô thị Nam Hòa Xuân (Sun Riverpolis)',
			'hh_p_scale'      => 'Thuộc khu đô thị sinh thái Nam Hòa Xuân 508 ha',
			'hh_p_units'      => 'Khoảng 900 lô (mở bán từ 9/8/2025)',
			'hh_p_unit_area'  => '100 – 150 m² (đất nền); khoảng 200 m² mặt tiền Nguyễn Phước Lan, Minh Mạng',
			'hh_p_price_from' => '4800',
			'hh_p_price_m2'   => 'Khoảng 40 – 48 triệu/m² (tham khảo)',
			'hh_p_ownership'  => 'Sổ đỏ lâu dài',
			'hh_p_highlights' => "Phân khu bốn mặt giáp sông, cảnh quan sinh thái\nLô mặt tiền Nguyễn Phước Lan, Minh Mạng (đường 7,5 m)\nBiệt thự view sông gần cầu Trung Lương, đối diện Sunneva Island",
			'hh_p_dat-nen_desc'  => 'Quỹ lô theo các block Đầm Sen (giá tham khảo theo thị trường khi mở bán; thay đổi theo vị trí, hướng và đợt bán).',
			'hh_p_dat-nen_table' => "Lô 100 m² (169 lô) | 100 m² | Đường 7,5 m | Từ khoảng 4,8 tỷ\nLô 125 m² (101 lô) | 125 m² | Đường 7,5 m | Liên hệ\nLô 150 m² (9 lô) | 150 m² | Đường 7,5 m | Liên hệ\nBlock B2-122 | – | – | Khoảng 5,2 – 5,4 tỷ\nBlock B2-116 | – | – | Khoảng 5,4 – 5,5 tỷ\nBlock B2-111 | – | – | Khoảng 6 tỷ\nBlock B2-157 | – | – | Khoảng 8 tỷ\nMặt tiền Nguyễn Phước Lan, Minh Mạng | Khoảng 200 m² | Đường 7,5 m | Liên hệ",
			'hh_p_villa_desc'    => 'Đất biệt thự view sông gần cầu Trung Lương (khoảng 68 – 92 lô) và dãy biệt thự view sông đối diện Sunneva Island (khoảng 24 lô) – liên hệ để nhận danh sách lô.',
			'hh_p_progress'   => '9/8/2025 | Sun Group mở bán khoảng 900 lô đất nền khu Đầm Sen',
		),
		'sources' => array( 'https://datnenhoaxuan.com/mo-ban-riverpolis-dam-sen', 'https://kingreal.com/to-hop-sun-riverpolis-da-nang/', 'https://sungroupvn.com.vn/sun-riverpolis/' ),
	);

	/* ---------------- Trung tâm & ven biển: Sun Solar Residence, Sun Costa Residence ---------------- */
	$projects[] = array(
		'slug'    => 'sun-solar-residence',
		'title'   => 'Sun Solar Residence Đà Nẵng',
		'type'    => 'can-ho-so-huu-lau-dai',
		'area'    => 'hai-chau',
		'hot'     => true,
		'excerpt' => 'Tháp căn hộ cao cấp của Sun Group trên đường Lê Duẩn, lõi trung tâm Hải Châu, cách cầu quay sông Hàn khoảng 300 m: 1 tòa 20 tầng, khoảng 256 căn hộ hướng sông Hàn.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => $sun,
			'hh_p_type'       => 'Căn hộ cao cấp',
			'hh_p_address'    => '9 Lê Duẩn, phường Hải Châu, Đà Nẵng – cách cầu sông Hàn khoảng 300 m',
			'hh_p_blocks'     => '1 tòa',
			'hh_p_floors'     => '20 tầng nổi (số tầng hầm các nguồn ghi 2 – 3)',
			'hh_p_units'      => 'Khoảng 256 căn hộ',
			'hh_p_highlights' => "Lõi trung tâm Hải Châu, trên trục Lê Duẩn – cách cầu sông Hàn khoảng 300 m\nTầm nhìn hướng sông Hàn, gần phố đi bộ Bạch Đằng, chợ Hàn\nSố lượng căn ít (khoảng 256 căn) – dòng căn hộ cao cấp giới hạn",
			'hh_p_amenities_in' => "Hồ bơi bốn mùa\nGym, yoga, spa\nKhu vui chơi trẻ em\n(Theo thông tin đơn vị phân phối)",
			'hh_p_location_desc' => 'Sun Solar Residence nằm trên đường Lê Duẩn, khu lõi trung tâm hành chính – thương mại của Đà Nẵng, cách cầu sông Hàn khoảng 300 m, đi bộ ra bờ sông Hàn, phố Bạch Đằng, chợ Hàn.',
			'hh_p_connections' => "300 m | Cầu sông Hàn\n5 phút | Chợ Hàn, phố đi bộ Bạch Đằng\n10 phút | Sân bay quốc tế Đà Nẵng\n10 phút | Biển Mỹ Khê",
		),
		'sources' => array( 'https://vnexpress.net/sun-group-ra-mat-thap-can-ho-cao-cap-giua-trung-tam-da-nang-4894133.html', 'https://vnexpress.net/vi-tri-ton-gia-tri-can-ho-hang-sang-sun-solar-residence-4903111.html', 'https://dantri.com.vn/bat-dong-san/sun-solar-residence-va-vi-the-giua-tam-mach-phon-hoa-da-nang-20250617225714160.htm' ),
	);
	$projects[] = array(
		'slug'    => 'sun-costa-residence',
		'title'   => 'Sun Costa Residence Đà Nẵng',
		'type'    => 'can-ho-dich-vu',
		'area'    => 'son-tra',
		'hot'     => true,
		'excerpt' => 'Tổ hợp căn hộ cận biển Mỹ Khê của Sun Group tại nút giao Hồ Nghinh – Vương Thừa Vũ (Sơn Trà): 2 tòa 25 tầng, khoảng 640 căn, phần lớn là studio – dòng sản phẩm hướng đến ở và cho thuê du lịch.',
		'meta'    => array(
			'hh_p_status'     => 'dang-mo-ban',
			'hh_p_developer'  => $sun,
			'hh_p_type'       => 'Căn hộ thương mại dịch vụ (studio – 2 phòng ngủ)',
			'hh_p_address'    => 'Nút giao Hồ Nghinh – Vương Thừa Vũ, phường Phước Mỹ (cũ), Sơn Trà, Đà Nẵng – cách biển Mỹ Khê khoảng 200 – 300 m',
			'hh_p_scale'      => 'Khu đất khoảng 3.800 – 4.000 m²',
			'hh_p_blocks'     => '2 tòa',
			'hh_p_floors'     => '25 tầng',
			'hh_p_units'      => 'Khoảng 640 căn (khoảng 80% là studio)',
			'hh_p_unit_area'  => 'Khoảng 33,8 – 72 m²',
			'hh_p_ownership'  => 'Sở hữu có thời hạn (căn hộ thương mại dịch vụ)',
			'hh_p_start'      => '2025',
			'hh_p_handover'   => 'Dự kiến 2027 (các nguồn ghi khác nhau – cần đối chiếu chủ đầu tư)',
			'hh_p_highlights' => "Cách biển Mỹ Khê khoảng 200 – 300 m, khu phố du lịch sôi động Hồ Nghinh – Vương Thừa Vũ\nPhần lớn là studio diện tích nhỏ – vốn vào thấp, hợp cho thuê ngắn hạn\nSản phẩm đầu tiên trong bộ sưu tập bất động sản phiên bản giới hạn của Sun Property tại Đà Nẵng",
			'hh_p_location_desc' => 'Sun Costa Residence nằm tại nút giao Hồ Nghinh – Vương Thừa Vũ, khu An Thượng – Phước Mỹ (Sơn Trà), cách biển Mỹ Khê vài trăm mét – khu vực tập trung khách sạn, nhà hàng và lượng khách du lịch lớn của Đà Nẵng.',
			'hh_p_connections' => "200 – 300 m | Biển Mỹ Khê\n5 phút | Cầu Rồng, cầu sông Hàn\n10 phút | Sân bay quốc tế Đà Nẵng\n15 phút | Bán đảo Sơn Trà",
		),
		'sources' => array( 'https://congly.com.vn/sun-costa-residence-can-ho-can-bien-my-khe-tam-diem-du-lich-da-nang/', 'https://congly.com.vn/sun-costa-residence-to-hop-bat-dong-san-can-bien-sinh-loi-tai-da-nang/' ),
	);

	// Bản 2.20.67 ghi nhầm "bờ Đông" và trỏ trang Galaxy về sun-danangdowntown.com (nay canonical là sun-galaxy-complex.com.vn):
	// thay bài giới thiệu nếu vẫn đúng bản cũ do web nhập
	$old = array(
		'da-nang-downtown'   => array(
			'ven bờ Tây sông Hàn giữa' => 'ven bờ Đông sông Hàn giữa',
			'<li><a href="https://www.sun-galaxy-complex.com.vn/">Sun Galaxy Complex</a>: ' => '<li><a href="https://www.sun-danangdowntown.com/sun-galaxy-complex">Sun Galaxy Complex</a> (hoặc <a href="https://www.sun-galaxy-complex.com.vn/">sun-galaxy-complex.com.vn</a>): ',
		),
		'sun-galaxy-complex' => array(
			'<a href="https://www.sun-galaxy-complex.com.vn/">sun-galaxy-complex.com.vn</a>.</p>' => '<a href="https://www.sun-galaxy-complex.com.vn/">sun-galaxy-complex.com.vn</a> hoặc <a href="https://www.sun-danangdowntown.com/sun-galaxy-complex">trang Sun Galaxy Complex trên Đà Nẵng Downtown</a>.</p>',
		),
	);
	foreach ( $projects as $i => $p ) {
		$slug = $p['slug'] ?? '';
		if ( isset( $old[ $slug ] ) && ! empty( $p['content'] ) ) {
			$projects[ $i ]['fix_content'] = array( strtr( $p['content'], $old[ $slug ] ) );
		}
	}

	return $projects;
}
