<?php
/**
 * Rank Math cho trang dự án:
 * - Tự điền "Từ khóa chính" (tên dự án + "giá …" + "bảng giá …") cho dự án chưa có.
 * - Tự điền "Tiêu đề SEO": "{Tên}: Bảng giá, chính sách {tháng/năm cập nhật} | Hoàng Hiệp" (≤ 60 ký tự).
 * - Cho bộ chấm điểm của Rank Math đọc cả nội dung trong các tab Thông tin dự án
 *   (trên web các phần này đều hiển thị, nhưng Rank Math chỉ đọc ô soạn thảo chính).
 */

defined( 'ABSPATH' ) || exit;

/** Từ khóa chính của dự án: khớp đường dẫn (slug) để đạt tiêu chí "từ khóa trong URL". */
/**
 * Từ khoá / tiêu đề riêng cho dự án ưu tiên, theo truy vấn thật trên Google Search Console (11/2026).
 * Sun Saphia: trang dự án giữ "Sun Saphia Residence", "Sun Saphia Đà Nẵng"; bài /gia-sun-saphia-residence-bao-nhieu/ giữ "giá … bao nhiêu".
 */
function hh_rm_project_overrides() {
	return array(
		'sun-saphia-residence' => array(
			'kw'     => 'Sun Saphia Residence,Sun Saphia Đà Nẵng,bảng giá Sun Saphia Residence,Sun Sapphire Residence',
			'kw_old' => array( 'Sun Saphia Residence,Sun Saphia Đà Nẵng,bảng giá Sun Saphia Residence' ),
			'title' => 'Sun Saphia Residence Đà Nẵng: Giá, mặt bằng %s',
		),
		'nobu-da-nang' => array(
			'kw'     => 'Nobu Residences Đà Nẵng,Nobu Đà Nẵng,bảng giá Nobu Residences Đà Nẵng',
			'kw_old' => array( 'Nobu Residences Đà Nẵng,Nobu Đà Nẵng,giá Nobu Residences Đà Nẵng' ),
			'title' => 'Nobu Residences Đà Nẵng: Giá bán, tiến độ %s',
		),
		'cora-tower' => array(
			'kw'     => 'Cora Tower Đà Nẵng,Cora Tower,bảng giá Cora Tower',
			'kw_old' => array( 'Cora Tower Đà Nẵng,Cora Tower,giá Cora Tower' ),
			'title' => 'Cora Tower Đà Nẵng: Giá từ 2,42 tỷ, chính sách %s',
		),
		'the-legend-da-nang' => array(
			'kw'     => 'The Legend Đà Nẵng,The Legend City Đà Nẵng,bảng giá The Legend Đà Nẵng',
			'kw_old' => array( 'The Legend Đà Nẵng,The Legend City Đà Nẵng,giá The Legend Đà Nẵng', 'The Legend Đà Nẵng,The Legend Sun Group,giá The Legend Đà Nẵng' ),
			'title' => 'The Legend Đà Nẵng (Legend City): Giá, chính sách %s',
		),
		'capital-square-da-nang' => array(
			'kw'    => 'Capital Square Đà Nẵng,Capital Square,bảng giá Capital Square',
			'title' => 'Capital Square Đà Nẵng: Bảng giá, chính sách %s',
		),
		'the-poet-residence-da-nang' => array(
			'kw'    => 'The Poet Residence Đà Nẵng,The Poet Residence,giá The Poet Residence',
			'title' => 'The Poet Residence Đà Nẵng: Giá từ 4,94 tỷ (%s)',
		),
		'casamia-balanca-hoi-an' => array(
			'kw'    => 'Casamia Balanca Hội An,Casamia Balanca,giá biệt thự Casamia Balanca',
			'title' => 'Casamia Balanca Hội An: Giá biệt thự, chính sách %s',
		),
		'symphony-5-sun-symphony-residence' => array(
			'kw'     => 'Sun Symphony 5,Symphony 5 Đà Nẵng,bảng giá Sun Symphony 5,Sun Symphony Residence 5',
			'kw_old' => array( 'Symphony 5 Đà Nẵng,Symphony 5 Sun Symphony Residence,giá Symphony 5', 'Sun Symphony 5,Symphony 5 Đà Nẵng,giá Sun Symphony 5,Sun Symphony Residence 5' ),
			'title'  => 'Sun Symphony 5 Đà Nẵng: Bảng giá, chính sách %s',
		),
		'fours-tower' => array(
			'kw' => 'FourS Tower,FourS Tower Đà Nẵng,Four S Tower,giá FourS Tower',
		),
		'spana-tower' => array(
			'kw'    => 'Spana Tower,Spana Tower Hòa Xuân,Spana Tower Đà Nẵng,Sun Spana Tower',
			'title' => 'Spana Tower Hòa Xuân Đà Nẵng: Bảng giá, chính sách %s',
		),
		's-light-tower' => array(
			'kw'    => 'S-Light Tower Đà Nẵng,S-Light Tower,S Light Tower Đà Nẵng,giá S-Light Tower',
			'title' => 'S-Light Tower Đà Nẵng: Bảng giá, chính sách %s',
		),
	);
}

function hh_rm_project_keywords( $post ) {
	$ov = hh_rm_project_overrides()[ $post->post_name ] ?? null;
	if ( $ov ) {
		return $ov['kw'];
	}
	return hh_rm_project_keywords_auto( $post );
}

/** Từ khoá web tự tính (khi dự án không có từ khoá riêng). */
function hh_rm_project_keywords_auto( $post ) {
	$name = trim( preg_replace( '/\s*\([^)]*\)/u', '', html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' ) ) );
	$slug = '-' . $post->post_name . '-';
	$main = '';
	// Cụm từ liền nhau dài nhất trong tên dự án nằm trọn trong đường dẫn (VD "Capital Square", "FourS Tower").
	foreach ( preg_split( '/\s+[–—-]\s+/u', $name ) as $seg ) {
		$w = preg_split( '/\s+/u', trim( $seg ) );
		$n = count( $w );
		for ( $i = 0; $i < $n; $i++ ) {
			for ( $j = $n; $j > $i; $j-- ) {
				$cand = implode( ' ', array_slice( $w, $i, $j - $i ) );
				if ( preg_match( '/^[&+]|[&+]$|^(đà nẵng|da nang|danang|hội an|hoi an|quảng nam|sơn trà)$/iu', $cand ) ) {
					continue; // Bỏ cụm cụt ("Resort &") hoặc chỉ là tên địa phương.
				}
				if ( mb_strlen( $cand ) > mb_strlen( $main ) && mb_strlen( $cand ) >= 4 && false !== strpos( $slug, '-' . sanitize_title( $cand ) . '-' ) ) {
					$main = $cand;
				}
			}
		}
	}
	$main = $main && preg_match( '/^[\p{Lu}\d]/u', $main ) ? $main : $name;
	// Tòa / phân khu con trùng từ khoá với dự án mẹ (VD Capital Square – Tòa 2.1): dùng tên đầy đủ để mỗi trang 1 từ khoá.
	if ( false !== strpos( $name, ' – ' ) && hh_rm_main_shared( $main, $post ) ) {
		$main = trim( preg_replace( '/\s+(Đà Nẵng|Da Nang|Danang)(?=\s|$)/u', '', str_replace( ' – ', ' ', $name ) ) );
	}
	$short = preg_match( '/\bNam\s+Hội An$/u', $main ) ? $main : ( trim( preg_replace( '/\s+(Đà Nẵng|Da Nang|Danang|Hội An|Hoi An|Quảng Nam)$/iu', '', $main ) ) ?: $main );
	return implode( ',', array_unique( array( $main, 'giá ' . $short, 'bảng giá ' . $short ) ) );
}

/** Từ khoá chính (cách tính gốc) đang dùng chung với dự án khác có đường dẫn ngắn hơn (dự án mẹ). */
function hh_rm_main_shared( $main, $post ) {
	static $map = null;
	if ( null === $map ) {
		$map = array();
		foreach ( get_posts( array( 'post_type' => 'du-an', 'post_status' => array( 'publish', 'future', 'draft', 'pending' ), 'posts_per_page' => -1 ) ) as $p ) {
			$k           = mb_strtolower( explode( ',', hh_rm_project_keywords_legacy( $p ) )[0] );
			$map[ $k ][] = $p->post_name;
		}
	}
	$list = $map[ mb_strtolower( $main ) ] ?? array();
	if ( count( $list ) < 2 ) {
		return false;
	}
	usort( $list, static fn( $a, $b ) => strlen( $a ) - strlen( $b ) );
	return $list[0] !== $post->post_name; // Dự án mẹ (đường dẫn ngắn nhất) giữ từ khoá gốc.
}

/** Cách tính từ khoá cũ (≤ 2.17) – chỉ để nhận ra từ khoá web tự điền trước đây và thay bằng bản mới. */
function hh_rm_project_keywords_legacy( $post ) {
	$name = trim( preg_replace( '/\s*\([^)]*\)/u', '', html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' ) ) );
	$slug = '-' . $post->post_name . '-';
	$main = '';
	// Cụm từ liền nhau dài nhất trong tên dự án nằm trọn trong đường dẫn (VD "Capital Square", "FourS Tower").
	foreach ( preg_split( '/\s+[–—-]\s+/u', $name ) as $seg ) {
		$w = preg_split( '/\s+/u', trim( $seg ) );
		$n = count( $w );
		for ( $i = 0; $i < $n; $i++ ) {
			for ( $j = $n; $j > $i; $j-- ) {
				$cand = implode( ' ', array_slice( $w, $i, $j - $i ) );
				if ( preg_match( '/^[&+]|[&+]$|^(đà nẵng|da nang|danang|hội an|hoi an|quảng nam|sơn trà)$/iu', $cand ) ) {
					continue; // Bỏ cụm cụt ("Resort &") hoặc chỉ là tên địa phương.
				}
				if ( mb_strlen( $cand ) > mb_strlen( $main ) && mb_strlen( $cand ) >= 4 && false !== strpos( $slug, '-' . sanitize_title( $cand ) . '-' ) ) {
					$main = $cand;
				}
			}
		}
	}
	$main  = $main && preg_match( '/^[\p{Lu}\d]/u', $main ) ? $main : $name;
	$short = trim( preg_replace( '/\s+(Đà Nẵng|Da Nang|Danang|Hội An|Hoi An|Quảng Nam)$/iu', '', $main ) ) ?: $main;
	return implode( ',', array_unique( array( $main, 'giá ' . $short, 'bảng giá ' . $short ) ) );
}

/**
 * Tiêu đề SEO trang dự án: "{Tên}: Bảng giá, chính sách {tháng}/{năm} | Hoàng Hiệp" (≤ 60 ký tự, tự rút gọn).
 * Tháng/năm = lần cập nhật dữ liệu dự án gần nhất (không phải ngày hôm nay).
 */
function hh_rm_project_title( $post ) {
	$kw   = explode( ',', hh_rm_project_keywords( $post ) );
	$name = '';
	foreach ( $kw as $k ) {
		if ( 0 === strpos( $k, 'bảng giá ' ) ) {
			$name = trim( substr( $k, strlen( 'bảng giá ' ) ) );
		}
	}
	$name  = $name ?: trim( preg_replace( '/\s*\([^)]*\)/u', '', html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' ) ) );
	$when  = wp_date( 'm/Y', max( (int) get_post_modified_time( 'U', true, $post ), (int) get_post_meta( $post->ID, '_hh_data_touched', true ) ) );
	$ov    = hh_rm_project_overrides()[ $post->post_name ] ?? null;
	if ( $ov && ! empty( $ov['title'] ) ) {
		return sprintf( $ov['title'], $when );
	}
	$brand = function_exists( 'hoanghiep_opt' ) && hoanghiep_opt( 'hh_person_name' ) ? hoanghiep_opt( 'hh_person_name' ) : 'Hoàng Hiệp';
	// Đất nền đã bàn giao (chỉ còn chuyển nhượng): người tìm quan tâm giá đất và sổ đỏ, không phải chính sách bán hàng.
	if ( has_term( 'dat-nen', 'loai-du-an', $post ) && function_exists( 'hh_project_is_resale' ) && hh_project_is_resale( $post->ID ) ) {
		foreach ( array( $name . ': Giá đất, pháp lý ' . $when . ' | ' . $brand, $name . ': Giá đất, pháp lý ' . $when, $name . ': Giá đất ' . $when ) as $title ) {
			if ( mb_strlen( $title ) <= 60 ) {
				return $title;
			}
		}
	}
	// Nhà phố – shophouse đã bàn giao: người tìm hỏi giá chuyển nhượng.
	if ( has_term( 'shophouse', 'loai-du-an', $post ) && function_exists( 'hh_project_is_resale' ) && hh_project_is_resale( $post->ID ) ) {
		foreach ( array( $name . ': Giá chuyển nhượng ' . $when . ' | ' . $brand, $name . ': Giá chuyển nhượng ' . $when ) as $title ) {
			if ( mb_strlen( $title ) <= 60 ) {
				return $title;
			}
		}
	}
	foreach ( array(
		$name . ': Bảng giá, chính sách ' . $when . ' | ' . $brand,
		$name . ': Bảng giá, chính sách ' . $when,
		$name . ': Bảng giá ' . $when . ' | ' . $brand,
		$name . ': Bảng giá ' . $when,
	) as $title ) {
		if ( mb_strlen( $title ) <= 60 ) {
			return $title;
		}
	}
	return rtrim( mb_substr( $name, 0, 60 - mb_strlen( ': Bảng giá ' . $when ) - 1 ) ) . '…: Bảng giá ' . $when;
}

/** Ghi tiêu đề SEO dự án khi đang trống hoặc vẫn là bản web tự tạo lần trước (anh sửa tay thì giữ nguyên). */
function hh_rm_sync_project_title( $post ) {
	$cur  = (string) get_post_meta( $post->ID, 'rank_math_title', true );
	$auto = (string) get_post_meta( $post->ID, '_hh_rm_auto_title', true );
	if ( '' !== $cur && $cur !== $auto ) {
		return;
	}
	$new = hh_rm_project_title( $post );
	if ( $new !== $cur ) {
		update_post_meta( $post->ID, 'rank_math_title', $new );
	}
	update_post_meta( $post->ID, '_hh_rm_auto_title', $new );
}

/** Điền từ khóa cho dự án đang trống (chạy một lần mỗi phiên bản plugin, và khi lưu dự án). */
add_action( 'admin_init', 'hh_rm_fill_keywords' );
function hh_rm_fill_keywords() {
	if ( get_option( 'hh_rm_kw_done' ) === HH_CRM_VERSION || ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	$ids = get_posts(
		array(
			'post_type'      => 'du-an',
			'post_status'    => array( 'publish', 'future', 'draft', 'pending' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	// Dự án đã cập nhật giá / giỏ hàng / tài liệu trong 11/2026 (trước khi web tự ghi mốc cập nhật).
	if ( ! get_option( 'hh_data_touched_seed_1126' ) ) {
		foreach ( array( 'cora-tower', 'the-legend-da-nang', 'symphony-5-sun-symphony-residence', 'fours-tower', 'fours-tower-f1-thap-tung', 'fours-tower-f2-thap-mai', 'fours-tower-f5-thap-cuc', 'sun-riverpolis', 'peninsula-private-da-nang', 'grand-marina-da-nang', 'mia-center-point-da-nang', 'sun-saphia-residence' ) as $slug ) {
			$p_ = get_page_by_path( $slug, OBJECT, 'du-an' );
			if ( $p_ && (int) get_post_meta( $p_->ID, '_hh_data_touched', true ) < strtotime( '2026-11-09' ) ) {
				update_post_meta( $p_->ID, '_hh_data_touched', strtotime( '2026-11-09 12:00:00' ) );
			}
		}
		update_option( 'hh_data_touched_seed_1126', 1, false );
	}
	foreach ( $ids as $id ) {
		$cur = (string) get_post_meta( $id, 'rank_math_focus_keyword', true );
		// Trống, hoặc vẫn là từ khoá web tự điền theo cách cũ (anh chưa sửa tay) → điền bản mới.
		$p_ = get_post( $id );
		$ov = hh_rm_project_overrides()[ $p_->post_name ] ?? null;
		if ( $ov && $cur !== $ov['kw'] && ( '' === $cur || $cur === hh_rm_project_keywords_legacy( $p_ ) || $cur === hh_rm_project_keywords_auto( $p_ ) || in_array( $cur, (array) ( $ov['kw_old'] ?? array() ), true ) || 0 === strpos( $cur, 'Sun Saphia Residence,giá ' ) ) ) {
			$cur = ''; // Dự án có từ khoá riêng: thay bản web tự điền trước đây.
		}
		if ( '' === $cur || $cur === hh_rm_project_keywords_legacy( get_post( $id ) ) ) {
			update_post_meta( $id, 'rank_math_focus_keyword', hh_rm_project_keywords( get_post( $id ) ) );
		}
		hh_rm_sync_project_title( get_post( $id ) );
	}
	update_option( 'hh_rm_kw_done', HH_CRM_VERSION, false );
}

add_action(
	'save_post_du-an',
	static function ( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || 'auto-draft' === $post->post_status || '' === trim( $post->post_title ) ) {
			return;
		}
		if ( '' === (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true ) && empty( $_POST['rank_math_focus_keyword'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			update_post_meta( $post_id, 'rank_math_focus_keyword', hh_rm_project_keywords( $post ) );
		}
		if ( empty( $_POST['rank_math_title'] ) || (string) get_post_meta( $post_id, '_hh_rm_auto_title', true ) === wp_unslash( $_POST['rank_math_title'] ) ) { // phpcs:ignore
			hh_rm_sync_project_title( get_post( $post_id ) );
		}
	},
	30,
	2
);

/** Nội dung các tab Thông tin dự án dạng HTML, để Rank Math tính độ dài, mật độ từ khóa, tiêu đề phụ. */
function hh_rm_project_text( $post_id ) {
	$html = '';
	foreach ( hh_project_schema() as $group ) {
		$parts = array();
		foreach ( $group['fields'] as $key => $f ) {
			$type = $f['type'] ?? 'text';
			if ( ! in_array( $type, array( 'text', 'textarea', 'lines', 'table' ), true ) ) {
				continue;
			}
			$v = trim( (string) get_post_meta( $post_id, $key, true ) );
			if ( '' === $v || preg_match( '#^https?://#', $v ) ) {
				continue;
			}
			$parts[] = '<p>' . esc_html( $f['label'] ) . ': ' . nl2br( esc_html( str_replace( ' | ', ', ', $v ) ) ) . '</p>';
		}
		if ( $parts ) {
			$html .= '<h2>' . esc_html( $group['title'] ) . ' ' . esc_html( get_the_title( $post_id ) ) . '</h2>' . implode( '', $parts );
		}
	}
	return $html;
}

add_action( 'admin_enqueue_scripts', 'hh_rm_enqueue' );
function hh_rm_enqueue( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || 'du-an' !== get_post_type() || ! defined( 'RANK_MATH_VERSION' ) ) {
		return;
	}
	wp_enqueue_script( 'hh-rankmath', HH_CRM_URL . 'rankmath.js', array( 'wp-hooks' ), HH_CRM_VERSION, true );
	wp_localize_script( 'hh-rankmath', 'hhRankMath', array( 'content' => hh_rm_project_text( get_the_ID() ) ) );
}

/** Giao diện Hoàng Hiệp tự tạo mục lục bài viết → báo cho Rank Math để không chấm lỗi "không dùng Table of Contents plugin". */
add_filter(
	'rank_math/researches/toc_plugins',
	static function ( $plugins ) {
		$plugins['hoang-hiep-crm/hoang-hiep-crm.php'] = 'Mục lục Hoàng Hiệp';
		return $plugins;
	}
);

/** Bỏ mục chấm "Sử dụng Content AI" (dịch vụ trả phí của Rank Math, không phải yếu tố xếp hạng Google). */
add_filter(
	'rank_math/researches/tests',
	static function ( $tests ) {
		unset( $tests['hasContentAI'] );
		return $tests;
	},
	20
);

/*
 * Sitemap: bật trang Dự án (du-an) và Nhà đất (bat-dong-san) trong sitemap Rank Math.
 * Hai loại bài này do plugin đăng ký nên Rank Math để mặc định "không đưa vào sitemap" – Google khó tìm thấy.
 */
add_filter(
	'rank_math/sitemap/exclude_post_type',
	static fn( $exclude, $type ) => in_array( $type, array( 'du-an', 'bat-dong-san' ), true ) ? false : $exclude,
	10,
	2
);
add_action(
	'init',
	static function () {
		if ( '2' === get_option( 'hh_rm_sitemap_pt' ) || ! defined( 'RANK_MATH_VERSION' ) ) {
			return;
		}
		$opt = get_option( 'rank-math-options-sitemap' );
		if ( is_array( $opt ) ) {
			foreach ( array( 'du-an', 'bat-dong-san' ) as $type ) {
				$opt[ 'pt_' . $type . '_sitemap' ] = 'on';
			}
			update_option( 'rank-math-options-sitemap', $opt );
			if ( class_exists( '\RankMath\Sitemap\Cache' ) && method_exists( '\RankMath\Sitemap\Cache', 'invalidate_storage' ) ) {
				\RankMath\Sitemap\Cache::invalidate_storage();
			}
		}
		update_option( 'hh_rm_sitemap_pt', '2', false );
	},
	30
);
